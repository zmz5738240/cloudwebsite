<?php
require_once dirname(__FILE__) . '/../public/conn.php';
/**
 * 循环删除目录和文件
 * @param string $dir_name
 * @return bool
 */

function delete_dir_file($dir_name) {
    $result = false;
    if(is_dir($dir_name)){
        if ($handle = opendir($dir_name)) {
            while (false !== ($item = readdir($handle))) {
                if ($item != '.' && $item != '..') {
                    if (is_dir($dir_name . '/' . $item)) {
                        delete_dir_file($dir_name .  '/' . $item);
                    } else {
                        unlink($dir_name .  '/' . $item);
                    }
                }
            }
            closedir($handle);
            if (rmdir($dir_name)) {
                $result = true;
            }
        }
    }

    return $result;
}

try {
	
	$pdo = new PDO("mysql:host={$DB_HOSTNAME};port={$DB_hostport}", $DB_USERNAME, $DB_PASSWORD,array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,));
	$pdo->query("USE `{$DB_DATABASE}`");
	$token = md5(mt_rand());
	
	$pdo->query("UPDATE think_config SET value = '8.0.1' WHERE name = 'version'");
	$res2 = $pdo->query("UPDATE think_config SET value = '{$token}' WHERE name = 'token'");
	if($res2 ){
	 echo "升级成功!请访问后台清理缓存"; 
	delete_dir_file(dirname(dirname(__FILE__))."/runtime/cache/");
	delete_dir_file(dirname(dirname(__FILE__))."/runtime/temp/");
	 @unlink (__DIR__.'/update.php');
	}
}
catch(PDOException $e) 
{
	echo "请刷新页面   重复升级!".$e->getMessage();
	@unlink (__DIR__.'/update.php');
}
$pdo = null;

	
?>	