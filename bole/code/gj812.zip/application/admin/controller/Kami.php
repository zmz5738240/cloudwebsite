<?php

namespace app\admin\controller;
use app\api\model\ApimailModel;
use app\admin\model\CateGoryGroupModel;
use think\Db;

class Kami extends Base
{
    //*********************************************卡密*********************************************//
   
    public function index()
    {
 		 $key = input('key');
        $goodsid = input('id');
        $map = [];
        $code=-1;
        $msg="获取失败";
        $count=0;
        $Nowpage=1;
        $allpage=0;
        $page=isset($param['page'])?$param['page']:1;
 		if($page<1){
 			$page=1;
 		} 		
 		if($goodsid!=0 && !empty($goodsid)){
 			$map['think_mail.mpid']=$goodsid;
 		}
        if($key&&$key!==""){
            $map['think_mail.musernm'] = ['like',"%" . $key . "%"];          
        }
 		$limitlast=config('list_rows');
   	  	$limit=($page-1)*$limitlast;//分页开始数量
 		$ApimailM=new ApimailModel();
 		$count=$ApimailM->getAllCount($map);
 		
 		$allpage = intval(ceil($count/$limitlast));
 		$Nowpage = input('get.page') ? input('get.page'):1;	
 		$result=$ApimailM->getmailBywhere($map,$Nowpage, $limitlast);      
		$goodsdetail=Db::name('fl')->where('id',$goodsid)->find();
       if(input('get.page'))
        {
            return $result;
        }
        $this->assign('goodsname', $goodsdetail['mnamebie']); //当前页
        $this->assign('Nowpage', $Nowpage); //当前页
        $this->assign('allpage', $allpage); //总页数 
        $this->assign('val', $key);
        $this->assign('count', $count);   
        $this->assign('goodsid', $goodsid);
     
        return $this->fetch();
    }
  
      /**
     * 删除卡密
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function del_kami()
    {
        $id = input('param.id');
        $ApimailM = new ApimailModel();
        $flag = $ApimailM->delKami($id);
        return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
    }
     /**
     * [add_group 添加卡密]
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function add_kami()
    {
        $goodid = input('param.id');
		$shopdetail=Db::name('fl')->where('id',$goodid)->find();
        $this->assign('uid', session('uid'));
        $this->assign('shopdetail', $shopdetail);
        return $this->fetch();
    }
	 /**
     * 删除所有卡密
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function del_all()
    {
		$param=inputself();
    	$mpid=$param['mpid'];
		$result=Db::name('mail')->where(['mpid'=>$mpid])->delete();
		if($result===false){
            return json(['code' => -1, 'count' => '', 'msg' => '删除失败']);
        }else{
        	return json(['code' => 1, 'count' => $result, 'msg' => '删除成功'.$result.'条数据']);
        }
    }
	 /**
     * 删除所有卡密
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function del_guoqi()
    {
    
		$param=inputself();
    	$mpid=$param['mpid'];
		$result=Db::name('mail')->where(['mis_use'=>1])->delete();
		if($result===false){
            return json(['code' => -1, 'count' => '', 'msg' => '清理失败']);
        }else{
        	return json(['code' => 1, 'count' => $result, 'msg' => '删除成功'.$result.'条数据']);
        }	
    }
     /**
     * 导出卡密
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function export_kami()
    {
			$param=inputself();
 			$data=[];
	 		$param['create_time']=time();
	 		$param['userip']=getIP();
	 		$param['mflid']=isset($param['mflid'])?$param['mflid']:'';
 			$param['buynum']=isset($param['buynum'])?$param['buynum']:'';
 			if($param['mflid']=='' || $param['buynum']==''){
 				$msg='不能为空';
    				$code=-1;
    				$returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
 			}
 			$dataFl=Db::name('fl')->where('id',$param['mflid'])->find();
 			if(!$dataFl){
 					$msg='商品异常';
    				$code=-1;
    				$returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
 			}
 			$decrypt=$dataFl['decrypt'];
 			
 			$code=1;
        	$msg="获取成功";
        	
 			//开启事务
    		Db::startTrans();
    		try
    		{
    			//添加订单信息		
    			$orderid=createOrder();
    			$sql="insert ignore into think_info set mcard=:mcard,morder=:morder,mstatus=1,create_time=:create_time,update_time=:update_time,userip=:userip,mflid=:mflid,buynum=:buynum,maddtype=88";
           		$bool = Db::execute($sql,[
 								'mcard'=>$orderid.'_'.$param['buynum'],
 								'morder'=>$orderid.'_'.$param['buynum'],
 								'create_time'=>$param['create_time'],
 								'update_time'=>0,
 								'userip'=>$param['userip'],
 								'mflid'=>$param['mflid'],
 								'buynum'=>$param['buynum']				
 								]);
           
    			if($bool==false)
    			{
    				// 回滚事务
    				Db::rollback();
    				$msg='添加订单状态失败';
    				$code=-1;
    				$returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
		    				     
    			}
				$mailsql="SELECT * from think_mail where mpid=:mpid and mis_use=0 ORDER BY id asc LIMIT :beishu for update";
				$maildata =Db::query($mailsql,['mpid'=>$param['mflid'],
										'beishu'=>$param['buynum']
									 ]);
    			if($maildata==false)
    			{
    				// 回滚事务
                    Db::rollback();
                    $msg='提取卡密出错001';
                    $code=-1;
                    $returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
                    
    			}
    			$file="";
                $html="";
                if($decrypt==0){
                	foreach ($maildata as $v) 
	                {
	                	$mails[] = $v['musernm'];
	                    $ids[] = $v['id'];
	                    $file .= $v['musernm'];
	                    $file .= "\r";
	                    $html .= $v['musernm'];
	                    $html .= '<br />';
	                    $data[]=$v['musernm'];
	                }
                }elseif($decrypt==1){
                	foreach ($maildata as $v) 
	                {
	                	$mails[] =passport_decrypt($v['mpasswd'],DECRYPT_KEY);
	                    $ids[] = $v['id'];
	                    $file .= passport_decrypt($v['mpasswd'],DECRYPT_KEY);
	                    $file .= "\r";
	                    $html .= passport_decrypt($v['mpasswd'],DECRYPT_KEY);
	                    $html .= '<br/>';
	                    $data[]=passport_decrypt($v['mpasswd'],DECRYPT_KEY);
	                }
                }
                
                
                
               
    			$arr_string = join(',', $ids);
                $sql = "update think_mail set mis_use=1,update_time=:update_time,syddhao=:orderid where id in(".$arr_string.")";
         
                $updatemail = Db::execute($sql,['update_time'=>time(),'orderid'=>$orderid]);
    			if($updatemail==false)
    			{
    				// 回滚事务
                    Db::rollback();
                    
                    $msg='更新卡密状态出错001';
                    $code=-1;
                    $returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
		                  

    			}
    			
    			
    			
    			
    		}catch(\Exception $e){
					// 回滚事务
                    Db::rollback();
                    $msg=$e->getMessage();
                    $code=-1;
                    $returnData=[		
					'code'=>$code,
					'msg'=>$msg,
					'data'=>$data		
		 			];
		 			return json($returnData);
                    
    		}
    		Db::commit();
    		$returnData=[		
			'code'=>$code,
			'msg'=>$msg,
			'data'=>$data		
 			];
 			
            $sor = fopen('upload/'.$orderid.'_'.$param['buynum'].'.txt',"w");
            $fwbool=fwrite($sor,$file);
            
            fclose($sor);
            $this->redirect(url('kami/Downloadurl',['orderid'=>$orderid,'buynum'=>$param['buynum']]));   
			//$this->picDownload($orderid.'_'.$param['buynum'].'.txt');
    }
	

	//兼容部分浏览器下载时二次请求导出方法
	function Downloadurl(){
		$param=inputself();
	    $this->picDownload($param['orderid'].'_'.$param['buynum'].'.txt');
	}	
	
	//批量下载图片
 function picDownload($orderid){	 
            $filename = "./upload/" . $orderid . ".zip";
			if(!file_exists($uf)){		
            // 生成文件
            $zip = new \ZipArchive ();
            // 使用本类，linux需开启zlib，windows需取消php_zip.dll前的注释
            if ($zip->open ($filename ,\ZipArchive::OVERWRITE) !== true) {
                //OVERWRITE 参数会覆写压缩包的文件 文件必须已经存在
                if($zip->open ($filename ,\ZipArchive::CREATE) !== true){
                    // 文件不存在则生成一个新的文件 用CREATE打开文件会追加内容至zip
                    exit ( '无法打开文件，或者文件创建失败' );
                }
            }
			
					//iconv('utf-8','gb2312',$v),因为我的$v中含有中文，file_exists不识别中文，需要转码
                $urlfile=$_SERVER['DOCUMENT_ROOT']."/upload/".$orderid;			
                if(file_exists($urlfile)){
					//get_basename($v)，原来的basename()不识别中文，新建函数获取文件名
					//iconv('utf-8','gb2312',get_basename($v))还是中文问题，没有中文的话basename($v)即可
                    $zip->addFile($urlfile, iconv('utf-8','gb2312',$orderid));
                } else {
						//                    die('图片地址不对哦');
                    echo 'error';
				//删除在服务器上创建的$filename压缩文件
                    @unlink($filename);
                    exit;
                }
            
        // 关闭
        $zip->close ();
		}
        //下面是输出下载;
		
        header ( "Cache-Control: max-age=0" );
        header ( "Content-Description: File Transfer" );
        header ( 'Content-disposition: attachment; filename=' . basename ( $filename ) ); // 文件名
        header ( "Content-Type: application/zip" ); // zip格式的
        header ( "Content-Transfer-Encoding: binary" ); // 告诉浏览器，这是二进制文件
        header ( 'Content-Length: ' . filesize ( $filename ) ); // 告诉浏览器，文件大小
        @readfile ( $filename );//输出文件;
        @unlink($filename);
            exit;
      }
		

}