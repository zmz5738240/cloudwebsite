<?php
namespace app\jingdian\controller;
use app\jingdian\model\GoodsListModel;
use app\jingdian\model\OrderModel;
use app\jingdian\model\UserModel;
use think\Config;
use think\Loader;
use think\Db;
class Trc20 extends Base
{
    public function getReturn($code = 1, $msg = "成功", $data = null)
    {
        return array("code" => $code, "msg" => $msg, "data" => $data);
    }
	
	public function pay(){
        $orderId = input("orderId");
        $order = Db::name("usdt_order")->where("order_id", $orderId)->find();
		$this->assign('order', $order);  
		return $this->fetch();
    }
	//创建订单
    public function createOrder()
    {
        $this->closeEndOrder();
        $payId = input("payId");
        $pid = input("pid");
		
        if (!$payId || $payId == "") {
            return json($this->getReturn(-1, "请传入订单号"));
        }
		$ordermoney =Db::name('info')->where('mcard', $payId)->find();		
		$userresult=Db::name('member_payorder')->where('orderno', $payId)->find();	
		if(!empty($userresult['memberid'])){
			$price = $userresult['money'];
		}else{
			$price = $ordermoney['mamount'];
		}//重新从数据库读取订单金额
		
        if (!$price || $price == "") {
            return json($this->getReturn(-1, "请传入订单金额"));
        }
        if ($price <= 0) {
            return json($this->getReturn(-1, "订单金额必须大于0"));
        }
       if(config('usdt_rate')){
		   $reallyPrice = ceil($price/config('usdt_rate')*100);
	   }else{
		   $reallyPrice = ceil($price/6*100);
	   }
        

        $orderId = date("YmdHms") . rand(1, 9) . rand(1, 9) . rand(1, 9) . rand(1, 9);
        $ok = false;
        for ($i = 0; $i < 300; $i++) {
            $tmpPrice = $reallyPrice;
            $row = Db::execute("INSERT IGNORE INTO think_tmp_uprice (price,oid,create_date) VALUES ('" . $tmpPrice . "','".$orderId."','".time()."')");
            if ($row) {
                $ok = true;
                break;
            }
            $reallyPrice++;
        }

        if (!$ok) {
            return json($this->getReturn(-1, "订单超出负荷，请稍后重试"));
        }
        $reallyPrice = bcdiv($reallyPrice, 100,2);
        if (strlen(config('usdt_wallet'))<10) {
            return json($this->getReturn(-1, "请您先进入后台配置钱包地址"));
        }
        $payUrl = config('usdt_wallet');

        $res = Db::name("usdt_order")->where("pay_id", $payId)->find();
        if ($res) {
            return json($this->getReturn(-1, "商户订单号已存在"));
        }
        $createDate = time();
        $data = array(
            "close_date" => 0,
            "create_date" => time(),
            "order_id" => $orderId,
            "timeout" => time()+(60*config('usdt_expiration_time')),
            "pay_date" => 0,
            "pay_id" => $payId,
            "pid" => $pid,
            "pay_url" => $payUrl,
            "price" => $price,
            "really_price" => $reallyPrice,
            "state" => 0,
        );
        Db::name("usdt_order")->insert($data);
		return $this->redirect(url('@jingdian/Trc20/pay')."?orderId=".$orderId);
    }
	//查询订单状态
    public function checkOrder()
    {
        $this->closeEndOrder();
        $orderId = input("orderId");
        $order = Db::name("usdt_order")->where("order_id", $orderId)->find();
        
		$end    = time() * 1000;
		$start  = (time()-60*config('usdt_expiration_time')) * 1000;
		$params = [
			'limit'           => 300,
			'start'           => 0,
			'direction'       => 'in',
			'relatedAddress'  => config('usdt_wallet'),
			'start_timestamp' => $start,
			'end_timestamp'   => $end,
		];
		$url 	= config('usdt_proxy')?config('usdt_proxy'):"https://apilist.tronscan.org";
		$api    = $url."/api/token_trc20/transfers?" . http_build_query($params);
		$resp   = $this->getCurl($api);
		$data   = json_decode($resp, true);

		if (empty($data)) {
			return json($this->getReturn(-1, "为找到记录"));
		}
		foreach ($data['token_transfers'] as $transfer) {
			if ($transfer['to_address'] == config('usdt_wallet') && $transfer['finalResult'] == 'SUCCESS') {
				if($transfer['block_ts'] / 1000 > $order['create_date']&& $transfer['block_ts'] / 1000 < $order['timeout'] &&$transfer['quant'] / 1000000== $order['really_price']){
				    $trade = Db::name("usdt_order")->where("trade_id", $transfer['transaction_id'])->find();
                    if(!$trade){
                        $type =3;
						Db::name("tmp_uprice")
							->where("oid",$order['order_id'])
							->delete();
						Db::name("usdt_order")->where("id",$order['id'])->update(array("state"=>1,"pay_date"=>time(),"trade_id"=>$transfer['transaction_id'],"close_date"=>time()));			
						//发卡平台订单业务处理										
						$OrderM = new OrderModel();	
						$UserM = new UserModel();	
						$Orderresult=$OrderM->getOrder($order['pay_id']);
						$mapx['orderno|outorderno'] = $order['pay_id'];
						$userresult=Db::name('member_payorder')->where($mapx)->find();
					  if(!empty($userresult['memberid'])){
					      $type=1;
						  $data = [
								 'memberid' => $userresult['memberid'],
								  'money' => $order['price'],
								  'r2' => $order['pay_id'],
								  'r6' => $order['pay_id'],
								  'userip' => $userresult['ip'],
							  ];
						
								$order = $UserM->payMember($order['pay_id'], $data);			  
					  }else{
					          $type=2;
							  $data = [
								  'mstatus' => 0,
								  'update_time' => time(),
								  'mcard' => $order['pay_id'],
								  'morder' => $order['order_id'],
								  'mamount' => (float)$order['price'],
							  ];
							  $order = $OrderM->updateOrderStatus($order['pay_id'], $data);
					  }
					  //发卡平台订单业务处理
					   return json($this->getReturn(1, "ok",$type));
					  
                    }
				}
			}
		}
	    return json($this->getReturn(-1, "next"));
	
	}

    
    public function closeEndOrder(){
        $closeTime = time()-60*config('usdt_expiration_time');
        $close_date = time();
        $res = Db::name("usdt_order")
            ->where("create_date <=".$closeTime)
            ->where("state",0)
            ->update(array("state"=>-1,"close_date"=>$close_date));
		$tmp = Db::name("tmp_uprice")
                    ->where("create_date <=".$closeTime)
                    ->delete();
        if ($res){
            return json($this->getReturn(1,"成功清理".$res."条订单"));
        }else{
            return json($this->getReturn(1,"没有等待清理的订单"));
        }
    }

	public function test(){
		$url 	= config('usdt_proxy')?config('usdt_proxy'):"https://apilist.tronscan.org";
        $apizt = $this->check_url($url.'/api/listdonators');
        if($apizt){
            exit("OK 不用代理");
        }else{
            exit("NO 需要反向代理或更换海外外服务器");
        }
    }

    /**
     * 检测网址连接是否可用
     **/
    function check_url($url){
    	if (@fopen($url, 'r')==false) {
    			return false;
    	}
    	return true;
    }
    //发送Http请求
    function getCurl($url, $post = 0, $cookie = 0, $header = 0, $nobaody = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $klsf[] = 'Accept:*/*';
        $klsf[] = 'Accept-Language:zh-cn';
        //$klsf[] = 'Content-Type:application/json';
        $klsf[] = 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $klsf);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, true);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);
        }
        curl_setopt($ch, CURLOPT_TIMEOUT,60);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }

}