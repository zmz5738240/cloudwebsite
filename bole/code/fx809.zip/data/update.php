<?php
require_once dirname(__FILE__) . '/../public/conn.php';
/**
 * 循环删除目录和文件
 * @param string $dir_name
 * @return bool
 */

function delete_dir_file($dir_name) {
    $result = false;
    if(is_dir($dir_name)){
        if ($handle = opendir($dir_name)) {
            while (false !== ($item = readdir($handle))) {
                if ($item != '.' && $item != '..') {
                    if (is_dir($dir_name . '/' . $item)) {
                        delete_dir_file($dir_name .  '/' . $item);
                    } else {
                        unlink($dir_name .  '/' . $item);
                    }
                }
            }
            closedir($handle);
            if (rmdir($dir_name)) {
                $result = true;
            }
        }
    }

    return $result;
}

try {
	
	$pdo = new PDO("mysql:host={$DB_HOSTNAME};port={$DB_hostport}", $DB_USERNAME, $DB_PASSWORD,array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,));
	$pdo->query("USE `{$DB_DATABASE}`");
	
	$res = $pdo->exec("
	CREATE TABLE `think_tmp_uprice`  (
	  `price` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
	  `oid` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
	  `create_date` bigint(20) NOT NULL,
	  PRIMARY KEY (`price`) USING BTREE
	) ENGINE = MyISAM CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;
	CREATE TABLE `think_usdt_order`  (
	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
	  `close_date` bigint(20) NOT NULL,
	  `create_date` bigint(20) NOT NULL,
	  `timeout` bigint(20) NOT NULL,
	  `order_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
	  `trade_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
	  `pay_date` bigint(20) NOT NULL,
	  `pid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
	  `pay_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
	  `pay_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
	  `price` double NOT NULL,
	  `really_price` double NOT NULL,
	  `state` int(11) NOT NULL,
	  `type` int(11) NOT NULL,
	  PRIMARY KEY (`id`) USING BTREE
	) ENGINE = MyISAM CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;
	");

	$res = $pdo->query("INSERT INTO think_config (value, name) VALUES ('TRPS5ziK4B3ooPomFBF3wZ2cJC6Woyc7Ss', 'usdt_wallet')");
	$res = $pdo->query("INSERT INTO think_config (value, name) VALUES ('', 'usdt_rate')");
	$res = $pdo->query("INSERT INTO think_config (value, name) VALUES ('', 'usdt_proxy')");
	$res = $pdo->query("INSERT INTO think_config (value, name) VALUES ('10', 'usdt_expiration_time')");
	$res2 = $pdo->query("UPDATE think_config SET value = '8.0.9' WHERE name = 'version'");
	if($res2 ){
	 echo "升级成功!请访问后台清理缓存"; 
	delete_dir_file(dirname(dirname(__FILE__))."/runtime/cache/");
	delete_dir_file(dirname(dirname(__FILE__))."/runtime/temp/");
	 @unlink (__DIR__.'/update.php');
	}
}
catch(PDOException $e) 
{
	echo "请刷新页面   重复升级!".$e->getMessage();
	@unlink (__DIR__.'/update.php');
}
$pdo = null;

	
?>	