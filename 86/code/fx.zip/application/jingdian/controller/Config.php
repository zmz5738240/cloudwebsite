<?php
namespace app\jingdian\controller;
use app\jingdian\model\ConfigModel;
use think\Db;

class Config extends Base
{


    /**
     * 获取配置参数
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function index() {
        if(session('useraccount.id')!=session('child_useraccount.id') || !session('useraccount.id')){
        	$this->error('未知错误',url('user/uscenter'));
        }
        $fzconfig = cache('config_child_' . session('useraccount.id'));
		$subhosts = explode(',', config('sub_webhost'));
        $this->assign('fzconfig',$fzconfig);
		$this->assign('subhosts', $subhosts);
        return $this->fetch();
    }



    /**
     * 批量保存配置
     * @author [来利云商业源码&智能建站平台] [366802485@qq.com]
     */
    public function save($config){
    	if(session('useraccount.id')!=session('child_useraccount.id')){
        	$this->error('未知错误',url('user/uscenter'));
        }
       	$param = inputself();
		$url = $param['hostprefix'].$param['merchanthost'];   
		$config['web_host']=$url;
        $configModel = new ConfigModel();
        if($config && is_array($config)){
            foreach ($config as $name => $value) {
                $map = array('name' => $name,'memberid'=>session('useraccount.id'));
                $returnR=$configModel->SaveConfig($map,$value);
                
            }
        }
		$result=Db::name('member')->where('id',session('useraccount.id'))->update(['fzhost'=>$config['web_host']]);
        cache('config_child_'.session('useraccount.id'),null);
        $this->success('保存成功！');
    }

}