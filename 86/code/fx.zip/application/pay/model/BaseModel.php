<?php

namespace app\pay\model;
use think\Model;
use think\Db;

class BaseModel extends Model
{

}