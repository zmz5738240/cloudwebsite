<?php

return [

    //模板参数替换
    'view_replace_str' => array(
        '__CSS__' => '/static/mobile/css',
        '__JS__'  => '/static/mobile/js',
        '__IMG__' => '/static/mobile/img',	
        '__LAYJS__' => '/static/admin/js',
        '__UPLOAD__' => '/upload',	
        '__ZYPAY__' => '/pay/zypay',
        '__ZYCARDPAY__' => '/pay/card',	
        '__ZFBGF__' => '/pay/zfb',
        '__WXGF__' => '/pay/wxpay/example/native.php',
        '__GZH__' => '/static/mobile/gzh',
        '__IMGMOBILE__' => '/static/mobile/imgmobile',
		//优云宝
	    '__MYOUYUNBAO__' => '/static/mobile/youyunbao',
        //uscenter
	    '__USCENTER__' => '/static/jingdian/uscenter',
	    //917模版
        '__LOAD917__' => '/static/jingdian/917',
        //geetest
	    '__GT__' => '/static/jingdian/geetest', 
	    //积分商城
	    '__MJF__' => '/static/mobile/integral',
    ),
   

];
