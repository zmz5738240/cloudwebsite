<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\libs;


class Router
{
    static $uri = '/';
    static $router = array(0 => 'index', 1 => 'main');
    static function get()
    {
        if (Req::server('REQUEST_URI')) {
            self::$uri = Req::server('REQUEST_URI');
        }
        else if (Req::server('REDIRECT_URL')) {
            self::$uri = Req::server('REDIRECT_URL');
        }
        else if (Req::server('HTTP_X_REWRITE_URL')) {
            self::$uri = Req::server('HTTP_X_REWRITE_URL');
        }
        return self::$uri;
    }
    static function put()
    {
        self::get();
        if (strpos(self::$uri, '?')) {
            $arr = explode('?', self::$uri);
            self::$uri = $arr[0];
        }
        if (self::$uri == '/') {
            return self::$router;
        }
        $arr = explode('/', self::$uri);
        $arr2 = array();
        foreach ($arr as $val) {
            if ($val != '') {
                $arr2[] = $val;
            }
        }
  return $arr2;
    }
}
?>