<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\libs;


class Session
{
    public static function set($name, $val)
    {
        $_SESSION[$name] = $val;
    }
    public static function get($name)
    {
        return isset($_SESSION[$name]) && $_SESSION[$name] ? $_SESSION[$name] : false;
    }
}
?>