<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app;

use BL\app\libs\Router;
use BL\app\libs\Log;

class blapp
{
    private static $instance = null;
    static $modelObj = null;
    function __construct()
    {
        spl_autoload_register(array($this, 'loadClass'));
    }
    static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new blapp();
        }
        return self::$instance;
    }
    public function loadClass($class)
    {
        $class = str_replace('BL\\app', '', $class);
        $class = str_replace('\\', '/', $class);
        $file = BL_ROOT . '' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
        } else {
			$class = str_replace('/controller/', '', $class);
            $msg = $class . '加载失败.';
            $url = base64_decode("d3d3LmxhaWxpeXVuLmNvbQ==");			
			require_once BL_ROOT.'/libs/err.php';
            exit;
        }
    }
    public function run()
    {
        $router = Router::put();
        if (file_exists(BL_ROOT . '/controller/' . $router[0])) {
            $className = !isset($router[1]) ? 'main' : $router[1];
            $class = __NAMESPACE__ . '\\controller\\' . $router[0] . '\\' . $className;
            if ($className == 'main') {
                $method = isset($router[1]) && $router[1] ? $router[1] : 'index';
            } else {
                $method = isset($router[2]) && $router[2] ? $router[2] : 'index';
            }
        } else {
            $class =  __NAMESPACE__ . '\\controller\\' . $router[0];
            $method = isset($router[1]) && $router[1] ? $router[1] : 'index';
        }
		$this->loadClass($class);
        $object = new $class();
        $method = method_exists($object, $method) ? $method : 'index';
        $object->{$method}();

    }

       
}