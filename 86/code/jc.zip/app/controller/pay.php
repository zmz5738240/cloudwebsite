<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller;

use BL\app\controller\PayBase;
use BL\app\libs\Lanpay;
use BL\app\libs\WxpayService;
use Payment\Client\Charge;
use Payment\Common\PayException;
use Payment\Config;
class pay
{
    

    /**
     * 支付方法
     */
    public function index()
    {
        $payDao = new PayBase();
        $id = $payDao->req->get('id');
        $type = $payDao->req->get('type');
        $paycode = $payDao->req->get('paycode');
        //查询订单是否存在
        $order = $payDao->model()->select()->from('orders')->where(array('fields' => 'orderid=?', 'values' => array($id)))->fetchRow();
        if(!$order)exit('非法请求，已记录ip');		
        $url = $payDao->urlbase . $payDao->req->server('HTTP_HOST') . '/pay/' . $paycode;
        $url .= '?orderid=' . $id . '&paycode=' . $type;
        $payDao->res->redirect($url);
    }
    public function zfbf2f()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('orderid');
        $order = $payDao->checkOrder($orderid);
        $payconf = $payDao->checkAcp("1");
        $config = [
        'use_sandbox' => false,
        'app_id' => $payconf['app_id'],    //应用appid
        'sign_type' => 'RSA2',
        'ali_public_key' => $payconf['ali_public_key'],
        'rsa_private_key' => $payconf['rsa_private_key'],
        'notify_url' => $payDao->urlbase . $payDao->url_host . '/notify/zfbf2f',                      //异步通知地址
        'return_url	' =>  $payDao->urlbase . $payDao->url_host . '/chaka?oid='.$order['orderid'],
        'return_raw' => true
        ];
        $data = [
            'order_no' => $order['orderid'],     //商户订单号，需要保证唯一
            'amount' => $order['cmoney'],           //订单金额，单位 元
            'subject' => $payDao->config['diyname']?$payDao->config['diyname']:$orderid,      //订单标题
            'body' => $order['orderid'],      //订单标题
        ];
        try {
            $str = Charge::run(Config::ALI_CHANNEL_QR, $config, $data);
        } catch (PayException $e) {
            echo $e->errorMessage();
            exit;
        }
        $data['str']=$str;
        $data['order']=$order;
	    $payDao->put('pay/f2f.php', $data);
    }
    public function wx()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('orderid');
        $order = $payDao->checkOrder($orderid);
        $payconf = $payDao->checkAcp("1");
        $mchid = $payconf['mch_id'];          //微信支付商户号 PartnerID 通过微信支付商户资料审核后邮件发送
        $appid = $payconf['wx_appid'];  //公众号APPID 通过微信支付商户资料审核后邮件发送
        $apiKey = $payconf['wx_apiKey'];   //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
        $wxPay = new WxpayService($mchid,$appid,$apiKey);
        $outTradeNo = $order['orderid'];     //你自己的商品订单号
        $payAmount = $order['cmoney'];          //付款金额，单位:元
        $orderName = $payDao->config['diyname']?$payDao->config['diyname']:$orderid;    //订单标题
        $notifyUrl = $payDao->urlbase . $payDao->url_host . '/notify/wx';     //付款成功后的回调地址(不要有问号)
        $payTime = time();      //付款时间
        $arr = $wxPay->nativepay($payAmount,$outTradeNo,$orderName,$notifyUrl,$payTime);
        //生成二维码
        $data['str']=$arr['code_url'];
        $data['order']=$order;
	    $payDao->put('pay/wx.php', $data);
    }
    
    
    public function mqpay()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('orderid');
        $paycode = $payDao->req->get('paycode');
        if($paycode == "alipay"){
           $type=1;
        }
        if($paycode == "wxpay"){
           $type=3;
        }
        if($paycode == "jhpay"){
           $type=2;
        }
        $key = $payDao->checkmqAcp();
        $order = $payDao->checkOrder($orderid);
        $oid = $order['orderid'];//订单号
        $price = $order['cmoney']; //提交的价格
        $host =$payDao->urlbase . $payDao->url_host."/mq/createOrder";		
        $_sign = md5($oid.$order['id'].$type.$price.$key['value']);
        $p = "payId=".$oid.'&param='.$order['id'].'&type='.$type."&price=".str_replace(',', '', $price).'&sign='.$_sign.'&isHtml=1';
        $url =$host."?".$p;	
        header("Location:{$url}"); //跳转到支付页面
        exit;
    }
    public function mazf()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('orderid');
        $paycode = $payDao->req->get('paycode');
        $order = $payDao->checkOrder($orderid);
        $payconf = $payDao->checkAcp("1");
         if ($paycode == 'jhpay') {
        	$type = '4'; 
        }
         if ($paycode == 'wxpay') {
        	$type = '1'; 	
        }
         if ($paycode == 'alipay') {
        	$type = '2'; 
        }
        $mid=(int)$payconf['pay_mzfid'];
        $key=$payconf['pay_mzfkey'];
        $beizhu=$order['oname'];
        $type=$type;
        $price=number_format($order['cmoney'], 2, '.', '');
        $payId=$order['orderid'];
        $sign =md5($mid . $payId . $beizhu . $type . $price . $key);
        $notifyUrl =$payDao->urlbase.$payDao->url_host.'/notify/mazf';//付款后通知该页面处理业务
        $returnUrl =$payDao->urlbase.$payDao->url_host .'/notify/mazf';//付款后通知该页面处理业务
        $url = "http://jk.lailiyun.com/createOrder/?isHtml=0&mid=".$mid."&payId=".$payId."&price=".$price."&type=".$type."&param=".$beizhu."&notifyUrl=".$notifyUrl."&returnUrl=".$returnUrl."&sign=".$sign; //生成支付URL
        
        if (function_exists('curl_init')) {
        	$ch = curl_init(); //使用curl请求
        	curl_setopt($ch, CURLOPT_URL, $url);
        	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        	$codepay_json = curl_exec($ch);
        	curl_close($ch);
        }else if(function_exists('file_get_contents')){
        	$context = array();
        	$context['http'] = array('timeout'=>5,'method' => 'GET'); 
        	$codepay_json =file_get_contents($url, false, stream_context_create($context));
        } 
        
       
        if (strpos($codepay_json,'code')) { //如果没有获取到远程HTML 则走JS创建订单
        	$json = json_decode($codepay_json,true);
        
        	if($json['code']!="1"){
        		$codepay_html = '<script>alert("'.$json['msg'].'");document.getElementById("timeOut").innerHTML = "支付数据创建失败！请联系网站客服";
                document.getElementById("timeOut").style.display = "";</script>';
        	}else{
        		$codepay_html = "<script>callback({$codepay_json})</script>"; //JSON数据
        		 
        	}
        }else{
            $codepay_html = '<script>document.getElementById("timeOut").innerHTML = "支付数据创建失败！请联系网站客服";
                document.getElementById("timeOut").style.display = "";</script>'; //JSON数据
        }
        
        $data['codepay_html']=$codepay_html;
        $data['order']=$order;
	    $payDao->put('pay/mzf.php', $data);
    }
    public function lailiyun()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('orderid');
        $paycode = $payDao->req->get('paycode');
        $order = $payDao->checkOrder($orderid);
        $payconf = $payDao->checkAcp("1");
        $is_defend = true;
        $notify_url = $payDao->urlbase.$payDao->url_host.'/notify/xw';
        $pay = new Lanpay($payconf['pay_yzfid'], $payconf['pay_yzfkey']);
        if($paycode=="wxpay"){
        	$payid="2";
        	$payname="微信";
    		$code_url = $pay->mp_pay($order['orderid'], $order['oname'], round($order['cmoney'],2), $notify_url);
        }else{
        	$payid="1";
        	$payname="支付宝";
        	$code_url = $pay->f2f_pay($order['orderid'], $order['oname'], round($order['cmoney'],2), $notify_url);
        }
        $data['str']=$code_url;
        $data['order']=$order;
        $data['payid']=$payid;
        $data['payname']=$payname;
	    $payDao->put('pay/xw.php', $data);
    }
    
    
    public function getshop()
    {
        $payDao = new PayBase();
        $orderid = $payDao->req->get('oid');
        $order = $payDao->checkOrder($orderid,2);
        if($order['status'] > 0){
            resMsg(1,$payDao->urlbase . $payDao->req->server('HTTP_HOST') . '/chaka?oid=' .$order['orderid']);
        }else{
            resMsg(0,null);
        }
    }
        

}