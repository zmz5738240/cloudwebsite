<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */


namespace BL\app\controller;

use BL\app\libs\Controller;
use BL\app\Config;

class clean extends Controller
{

    public function index()
    {
        $token = $this->req->get('token');
        if($token != $this->config['serive_token'])exit('非法请求，已记录ip');

        //清理过期订单
        $san = (time() - 259200);//三天
        $sanshi = (time() - 2626560);//三十天		 
        $this->model()->from('orders')->where(array('fields' => 'ctime < ? AND status = 0', 'values' => array($sanshi)))->delete();
        $this->model()->from('kami')->where(array('fields' => 'ctime < ? AND is_ste = 1', 'values' => array($sanshi)))->delete();
		
        if($this->config['ismail_kuc'] = 0) return;
        //查询有误库存告警，查询出所有上架商品信息
        $goodList = $this->model()->select()->from('goods')->where(array('fields' => 'is_ste = 1', 'values' => []))->orderby('id desc')->fetchAll();
        $mailtpl = $this->model()->select()->from('mailtpl')->where(array('fields' => 'is_state=? and cname=?', 'values' => array(0, '库存告警')))->fetchRow();
        $goodNames = "";
        foreach ($goodList as $v){
            if($v['kuc'] < $this->config['ismail_num']){
               $goodNames .= $v['gname']."--";
            }
        }

        if($goodNames != ""){
            echo trim($goodNames,'--').'库存不足</br>';
            $goodNames = trim($goodNames,'--');
            $info = [
                'sitename' => $this->config['sitename'],
                'gname' => $goodNames,
                'ornum' => $this->config['ismail_num'],
                'siteurl' => $this->config['siteurl'],
            ];
            $newData = $this->res->replaceMailTpl($mailtpl, $info);
            $subject = array('title' => $newData['title'], 'email' => $this->config['email'], 'content' => $newData['content']);
          

            $this->res->sendMail($subject, $this->config);
        }


    }



}