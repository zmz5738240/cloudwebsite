<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller;

use BL\app\controller\PayBase;
use BL\app\libs\Lanpay;
use BL\app\libs\WxpayService;
use BL\app\libs\AlipayService;
class notify
{
    
     public function zfbf2f()
    {
        $payDao = new PayBase();
        $model = '当面付';
        $payconf = $payDao->checkAcp("1");
        //支付宝公钥，账户中心->密钥管理->开放平台密钥，找到添加了支付功能的应用，根据你的加密类型，查看支付宝公钥
        $alipayPublicKey=$payconf['ali_public_key'];
        $aliPay = new AlipayService($alipayPublicKey);
        //验证签名
        $result = $aliPay->rsaCheck($_POST);
        if($result===true){
            if($_POST['trade_status'] == "TRADE_SUCCESS"&&$_POST['app_id']==$payconf['app_id']){
                $res = $payDao->updateOrder($_POST['out_trade_no'],$model,$_POST['trade_no']);
                echo 'success';exit();
            }
        
        }
        echo 'error';exit();
    }
     public function wx()
    {
        $payDao = new PayBase();
        $model = '微信支付';
        $payconf = $payDao->checkAcp('1');
        $mchid = $payconf['mch_id'];          //微信支付商户号 PartnerID 通过微信支付商户资料审核后邮件发送
        $appid = $payconf['wx_appid'];  //公众号APPID 通过微信支付商户资料审核后邮件发送
        $apiKey = $payconf['wx_apiKey'];   //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
        $wxPay = new WxpayService($mchid,$appid,$apiKey);
        $result = $wxPay->notify();
        if($result){
        	 $res = $payDao->updateOrder($result['out_trade_no'],$model,$result['transaction_id']);
        }else{
            echo 'pay error';
        }  
    }
     public function mazf()
    {
        $payDao = new PayBase();
        $payconf = $payDao->checkAcp('1');
        $sign = md5($payconf['pay_mzfid'] . $payDao->req->get('payId') . urldecode($payDao->req->get('param')) . $payDao->req->get('type') . $payDao->req->get('price') . $payDao->req->get('reallyPrice') .$payconf['pay_mzfkey']);
        if (!$payDao->req->get('payId') || $sign != $payDao->req->get('sign')) { //不合法的数据
        	exit('fail');  //返回失败 继续补单
        } else { //合法的数据
            $payarr=[1=>'微信', 2=>'支付宝', 3=>'QQ钱包', 4=>'聚合支持'];
            $res = $payDao->updateOrder($payDao->req->get('payId'),$payarr[$_GET['type']],$payDao->req->get('order_id'));
        
            exit('success'); //返回成功 不要删除哦
        }
    }
    
     public function xw()
    {
        $payDao = new PayBase();
        $model = '蓝支付';
        $payconf = $payDao->checkAcp("1");
        $pay = new Lanpay($payconf['pay_yzfid'], $payconf['pay_yzfkey']);
        $data = $_REQUEST;
        unset($data['q']);
        if ($pay->verify($data)) {
            if ($data['trade_status'] == 'TRADE_SUCCESS') {
        		$res = $payDao->updateOrder($data['out_trade_no'],$model,$data['trade_no']);
                exit('success');
            } else {
                exit('fail');
            }
        } else {
            exit('fail');
        }  
    }

}