<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;
use BL\app\libs\Controller;


class Upgrade extends CheckAdmin
{
  
    public function __construct() {
        parent::__construct();
        $this->version = '1.0';
        $this->error = "";
        $this->update_path = WEB_ROOT.'/data/uppack/';
        $this->update_back_path = WEB_ROOT.'/data/upback/';
        $this->cloud = new \BL\app\libs\Cloud($this->update_path);
        
    }  
    
    
    public function getVersion()
    {
        $result = $this->cloud->data(['appid' => '1','version' => versionToInteger($this->config['version'])])->api('update');
        if ($result) {
            if ($result['code'] == 1) {
                $length = count($result['data']);
                foreach ($result['data'] as $k => $v) {
                    $result['data'][$k]['version'] = versionToString($v['version']);
                    $result['data'][$k]['content'] = htmlspecialchars_decode($v['content']);
                    $result['data'][$k]['isupgrade'] = $k == 0 ? 1 : 0 ;  
                }
                $this->session->set('upgrade',$length?$result['data'][0]: 'a');
            }
           
        }
        
            return jsonecho($result); 
        
    }
    public function index()
    {
        
        $data = array('title' => '在线升级');
        $this->put('upgrade.php', $data);
    }
    
    
    public function down()
    {
        $upgrade  = $this->session->get('upgrade');
        if($this->req->post('version') != $upgrade['version']){
            return jsonecho(['code' => 2, 'msg' => '获取版本列表错误！请刷新重试']); 
        }
        $lock = $this->update_path.$upgrade['version'].'upgrade.lock';
        if (!is_file($lock)) {
            @file_put_contents($lock, time());
        } else {
            return jsonecho(['code' => 2, 'msg' => '升级任务执行中，请手动删除此文件后重试！<br>文件地址：/data/uppack/'.$upgrade['version'].'upgrade.lock']);
        }
        $file = $this->cloud->down($upgrade['update_file']);
       
        if ($file === false || empty($file)) {
            $this->clearCache($file);
            return jsonecho(['code' => 2, 'msg' => '获取升级包失败！']);
        }
        return jsonecho(['code' => 1, 'msg' => basename($file)]);
                
    }
    
    public function install()
    {
        $file =$this->req->post('file');
        $version =$this->req->post('version');
        if (empty($file) || empty($version)) {
            return jsonecho(['code' => 2, 'msg' => '参数传递错误！']);
        }
        $file = $this->update_path.$file;
        if (!file_exists($file)) {
            $this->clearCache($file);
            return json(['code' => 2, 'msg' => $version.' 升级包异常，请重新升级！']);
        }

        if (self::_install($file, $version) === false) {
            $this->clearCache($file);
            return jsonecho(['code' => 2, 'msg' => $this->error]);
        }
        return jsonecho(['code' => 1, 'msg' => '升级包安装成功。', 'url' => $this->dir."/Upgrade"]);
    }

    private function _install($file = '', $version = '')
    {
        if (empty($file) || empty($version)) {
            $this->error = '参数传递错误！';
            return false;
        }
         if (self::_systemInstall($file, $version)){
            $this->clearCache($file);  
         }
    }

    private function _systemInstall($file, $version)
    {
        $dir = new \BL\app\libs\Dir();
        if (!is_dir($this->update_back_path)) {
            $dir->create($this->update_back_path);
        }
        $decom_path = $this->update_path.basename($file,".zip");
        if (!is_dir($decom_path)) {
            $dir->create($decom_path, 0777, true);
        }
        // 解压升级包
        $archive = new \BL\app\libs\PclZip();
        $archive->PclZip($file);
        if(!$archive->extract(PCLZIP_OPT_PATH, $decom_path, PCLZIP_OPT_REPLACE_NEWER)) {
            $this->error = '升级失败，请开启[data/uppack]文件夹权限！';
            return false;
        }
         $_SESSION['upgrade'] = '';
        // 更新升级文件
        $dir->copyDir($decom_path, WEB_ROOT);
        return true;
    }
    

    private function clearCache($file = '', $version = '')
    {
        $upgrade  = $this->session->get('upgrade');
        if (is_file($this->update_path.$upgrade['version'].'upgrade.lock')) {
            unlink($this->update_path.$upgrade['version'].'upgrade.lock');
        }
        if (is_file($file)) {
            unlink($file);
        }
        // 删除升级解压文件
        if (is_dir($this->update_path)) {
            $dir = new \BL\app\libs\Dir();
            $dir->delDir($this->update_path);
        }
    }
}