<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;
use BL\app\libs\Controller;
use BL\app\controller\PayBase;

class mq extends CheckAdmin
{
    public function setting()
    {
        $data = array('title' => '免签设置');
        $this->put('mqsetting.php', $data);
    }
    
    public function jk()
    {
        $data = array('title' => '监控端设置');
        $this->put('mqjk.php', $data);
    }
    public function qrcode()
    {
        $data = array('title' => '二维码管理');
        $this->put('mqqrcode.php', $data);
    }
    public function qrcodeadd()
    {
        $data = array('title' => '新增二维码');
        $this->put('mqqrcodeadd.php', $data);
    }
    public function order()
    {
        $data = array('title' => '免签订单');
        $this->put('mqorder.php', $data);
    }
    
    
    

    public function getReturn($code = 1,$msg = "成功",$data = null){
        return array("code"=>$code,"msg"=>$msg,"data"=>$data);
    }



    public function getMain(){
        header('Content-Type:application/json');  //此声明非常重要
        $start = date('Y-m-d 00:00:00');
        $end = date('Y-m-d H:i:s');
       $todayOrder = $this->model()->select()->from('mqorder')->where(array('fields' => '`create_date` >= unix_timestamp( \''.$start.'\' ) AND `create_date` <= unix_timestamp( \''.$end.'\' )  '))->count();
       $todaySuccessOrder = $this->model()->select()->from('mqorder')->where(array('fields' => '`state` >= 1 AND `create_date` >= unix_timestamp( \''.$start.'\' ) AND `create_date` <= unix_timestamp( \''.$end.'\' )  '))->count();
     
       
       $todayCloseOrder = $this->model()->select()->from('mqorder')->where(array('fields' => '`state` = -1 AND `create_date` >= unix_timestamp( \''.$start.'\' ) AND `create_date` <= unix_timestamp( \''.$end.'\' )  '))->count();
     
       
       $todaymone =$this->model()->select(['price' => 'price'])->from('mqorder')->where(array('fields' => '`state` >= 1 AND `create_date` >= unix_timestamp( \''.$start.'\' ) AND `create_date` <= unix_timestamp( \''.$end.'\' )  '))->sum();
       $todayMoney = $todaymone['price'];
       
        $countOrder = $this->model()->select()->from('mqorder')->where(array('fields' => '`state` > 0'))->count();
        $countmon = $this->model()->select(['price' => 'price'])->from('mqorder')->where(array('fields' => '`state` >= 1'))->sum();
        $countMoney=$countmon['price'];
        exit(json_encode($this->getReturn(1,"获取成功",array(
            "todayOrder"=>$todayOrder,
            "todaySuccessOrder"=>$todaySuccessOrder,
            "todayCloseOrder"=>$todayCloseOrder,
            "todayMoney"=>round($todayMoney,2),
            "countOrder"=>$countOrder,
            "countMoney"=>round($countMoney),
        ))));

    }

    public function getSettings(){
        header('Content-Type:application/json');  //此声明非常重要
        $key = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "keyl"'))->fetchRow();
        $lastheart = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "lastheart"'))->fetchRow();
        $lastpay = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "lastpay"'))->fetchRow();
        $jkstate = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "jkstate"'))->fetchRow();
        $close = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "close"'))->fetchRow();
        $payQf = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "payQf"'))->fetchRow();
        $wxpay = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "wxpay"'))->fetchRow();
        $jhpay = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "jhpay"'))->fetchRow();
        $alipay = $this->model()->select()->from('mqsetting')->where(array('fields' => '`key` = "alipay"'))->fetchRow();
       
        exit(json_encode($this->getReturn(1,"成功",array(
            "key"=>$key['value'],
            "lastheart"=>$lastheart['value'],
            "lastpay"=>$lastpay['value'],
            "jkstate"=>$jkstate['value'],
            "close"=>$close['value'],
            "payQf"=>$payQf['value'],
            "wxpay"=>$wxpay['value'],
            "jhpay"=>$jhpay['value'],
            "alipay"=>$alipay['value'],
        ))));


    }
    public function saveSetting(){
        header('Content-Type:application/json');  //此声明非常重要
        foreach ($_POST as $k => $v){
           $this->model()->from('mqsetting')->updateSet(array('value' => $v))->where(array('fields' => '`key`=?', 'values' => array($k)))->update();
        }
        exit(json_encode($this->getReturn()));

    }


    public function addPayQrcode(){
        header('Content-Type:application/json');  //此声明非常重要
        $data = $this->getReqdata($_POST);
        $this->model()->from('mqqrcode')->insertData($data)->insert();
        exit(json_encode($this->getReturn()));

    }

    public function getPayQrcodes(){
        $page = $this->req->get('page');
        $size = $this->req->get('limit');
        $type = $this->req->get('type') ;
        $cons = '';
        $consArr = [];
        $cons.= 'id > 0';
        if($type < 666){
            $cons .= $cons ? ' and ' : '';
            $cons.= 'type = ?';
            $consArr[] = $type;
        }
        $offset = ($page - 1) * $size;
        
        $array = $this->model()->select()->from('mqqrcode')->where(array('fields' => $cons, 'values' => $consArr))->limit($size)->offset($offset)->orderby('id desc')->fetchAll();
        $count=$this->model()->select()->from('mqqrcode')->where(array('fields' => $cons, 'values' => $consArr))->count();
        //echo $obj->getLastSql();
        exit(json_encode(array(
            "code"=>0,
            "msg"=>"获取成功",
            "data"=>$array,
            "count"=> $count
        )));
    }
    public function delPayQrcode(){
        header('Content-Type:application/json');  //此声明非常重要
        $data = $this->getReqdata($_POST);
    	$tmp =$this->model()->from('mqqrcode')->where(array('fields' => '`id` =\''.$data['id'].'\''))->delete();
        exit(json_encode($this->getReturn()));
        
    	

    }

    public function getOrders(){
        header('Content-Type:application/json');  //此声明非常重要
        $page = $this->req->get('page');
        $size = $this->req->get('limit');
        $is_ste = $this->req->get('state');
        $type = $this->req->get('type') ;
        $cons = '';
        $consArr = [];
        $cons.= 'id > 0';
        
        if($is_ste < 666){
            $cons .= $cons ? ' and ' : '';
            $cons.= 'state = ?';
            $consArr[] = $is_ste;
        }

        if($type < 666){
            $cons .= $cons ? ' and ' : '';
            $cons.= 'type = ?';
            $consArr[] = $type;
        }
        $offset = ($page - 1) * $size;
        
        $array = $this->model()->select()->from('mqorder')->where(array('fields' => $cons, 'values' => $consArr))->limit($size)->offset($offset)->orderby('id desc')->fetchAll();
        $count=$this->model()->select()->from('mqorder')->where(array('fields' => $cons, 'values' => $consArr))->count();
        
         //print_r($array);
        exit(json_encode(array(
            "code"=>0,
            "msg"=>"获取成功",
            "data"=>$array,
            "count"=> $count
        )));
    }
    
    public function delOrder(){
        header('Content-Type:application/json');  //此声明非常重要
        $data = $this->getReqdata($_POST);
        $res = $this->model()->select()->from('mqorder')->where(array('fields' => '`id` =\''.$data['id'].'\''))->fetchRow();
        $order = $this->model()->select()->from('mqorder')->where(array('fields' => '`id` =\''.$data['id'].'\''))->delete();
        if ($res['state']==0){
            $temp =$this->model()->from('mqtmp_price')->where(array('fields' => '`oid` =\''.$res['order_id'].'\''))->delete();
        }

       exit(json_encode($this->getReturn()));

    }

    public function setBd(){
        header('Content-Type:application/json');  //此声明非常重要
        $data = $this->getReqdata($_POST);
        $res = $this->model()->select()->from('mqorder')->where(array('fields' => 'id=?', 'values' => array($data['id'])))->fetchRow();
       
        $payDao = new PayBase();
        if ($res){
					//发卡平台订单业务处理
        		if($res['type']==1){
        	         $model="支付宝";
        		}	
        		if($res['type']==2){
        	         $model="聚合码";
        		}	
        		if($res['type']==3){
        	         $model="微信";
        		}
                $payDao->updateOrder($res['pay_id'],$model,$res['order_id']);
				  //发卡平台订单业务处理
          
                if ($res['state']==0){
        	       $this->model()->from('mqtmp_price')->where(array('fields' => '`oid` =\''.$res['order_id'].'\''))->delete();
                }
                
                 $update = array('state' => "1");
                 $this->model()->from('mqorder')->updateSet($update)->where(array('fields' => 'id=?', 'values' => array($res['id'])))->update();
              
				exit(json_encode($this->getReturn(1,"补单成功")));
            
        }else{
            exit(json_encode($this->getReturn(-1,"订单不存在")));

        }


    }

    public function delGqOrder(){
        header('Content-Type:application/json');  //此声明非常重要
        $this->model()->from('mqorder')->where(array('fields' => 'state=?', 'values' => array("-1")))->delete();
        exit(json_encode($this->getReturn()));
        
    }
    public function delLastOrder(){
        header('Content-Type:application/json');  //此声明非常重要
        $this->model()->from('mqorder')->where(array('fields' => 'create_date<=?', 'values' => array(time()-604800)))->delete();
        exit(json_encode($this->getReturn()));
        
    }




    
}