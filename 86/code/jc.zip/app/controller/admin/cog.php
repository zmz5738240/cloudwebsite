<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;

use BL\app\libs\Controller;

class cog extends CheckAdmin
{
    public function index()
    {
        $data = array('title' => '系统设置');
        $this->put('cog.php', $data);
    }
    public function save()
    {
        $data = array();
        if (isset($_POST)) {
            foreach ($_POST as $key => $val) {
                $data[$key] = $this->req->post($key);
            }
        }
        if ($data) {
            $newdata = array('content' => json_encode($data));
            $this->model()->from('navcog')->delete();
            if ($this->model()->from('navcog')->insertData($newdata)->insert()) {
                echo json_encode(array('status' => 1, 'msg' => '设置保存成功', 'url' => $this->dir . 'cog'));
                exit;
            }
        }
        echo json_encode(array('status' => 0, 'msg' => '设置保存失败'));
        exit;
    }
}