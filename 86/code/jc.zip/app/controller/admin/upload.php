<?php
namespace BL\app\controller\admin;
use BL\app\libs\Controller;
class upload extends Controller
{
    public function index(){
			$ip = isset($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];			
			$admin_login=md5($ip);	
            if (!$this->session->get('login_adminname') || $this->session->get('admin_token')!=$admin_login) {
				if ($this->req->session('login_adminname')) {
					$_SESSION['login_adminname'] = '';
					unset($_SESSION['login_adminname']);
				}
				if ($this->req->session('login_adminid')) {
					$_SESSION['login_adminid'] = '';
					unset($_SESSION['login_adminid']);
				}
				if ($this->req->session('admin_token')) {
					$_SESSION['admin_token'] = '';
					unset($_SESSION['admin_token']);
				}
			header("HTTP/1.1 404 Not Found");
			exit();
			die();
		}else{
        
        //文件保存目录路径
        $save_path = web_path . '/upload/';
        //文件保存目录URL
        $save_url ='/upload/';
        
        //定义允许上传的文件扩展名
        $ext_arr = array(
        	'image' => array('gif', 'jpg', 'jpeg', 'png', 'bmp'),
        	'flash' => array('swf', 'flv'),
        	'media' => array('swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb'),
        	'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'txt', 'zip', 'rar', 'bz2'),
        );
        //最大文件大小
        $max_size = 500000;
        
        $save_path = realpath($save_path) . '/';
        //有上传文件时
        if (empty($_FILES) === false) {
        	//原文件名
        	$file_name = $_FILES['imgFile']['name'];
        	//服务器上临时文件名
        	$tmp_name = $_FILES['imgFile']['tmp_name'];
        	//文件大小
        	$file_size = $_FILES['imgFile']['size'];
        	//检查文件名
        	if (!$file_name) {
        		$this->alert("请选择文件。");
        	}
        	//检查目录
        	if (@is_dir($save_path) === false) {
        		$this->alert("上传目录不存在。");
        	}
        	//检查目录写权限
        	if (@is_writable($save_path) === false) {
        		$this->alert("上传目录没有写权限。");
        	}
        	//检查是否已上传
        	if (@is_uploaded_file($tmp_name) === false) {
        		$this->alert("临时文件可能不是上传文件。");
        	}
        	//检查文件大小
        	if ($file_size > $max_size) {
        		$this->alert("上传文件大小超过限制。");
        	}
        	//检查目录名
        	$dir_name = empty($_GET['dir']) ? 'image' : trim($_GET['dir']);
        	if (empty($ext_arr[$dir_name])) {
        		$this->alert("目录名不正确。");
        	}
        	//获得文件扩展名
        	$temp_arr = explode(".", $file_name);
        	$file_ext = array_pop($temp_arr);
        	$file_ext = trim($file_ext);
        	$file_ext = strtolower($file_ext);
        	//检查扩展名
        	if (in_array($file_ext, $ext_arr[$dir_name]) === false) {
        		$this->alert("上传文件扩展名是不允许的扩展名。\n只允许" . implode(",", $ext_arr[$dir_name]) . "格式。");
        	}
        	//创建文件夹
        	if ($dir_name !== '') {
        		$save_path .= $dir_name . "/";
        		$save_url .= $dir_name . "/";
        		if (!file_exists($save_path)) {
        			mkdir($save_path);
        		}
        	}
        	$ymd = date("Ymd");
        	$save_path .= $ymd . "/";
        	$save_url .= $ymd . "/";
        	if (!file_exists($save_path)) {
        		mkdir($save_path);
        	}
        	//新文件名
        	$new_file_name = date("YmdHis") . '_' . rand(10000, 99999) . '.' . $file_ext;
        	//移动文件
        	$file_path = $save_path . $new_file_name;
        	if (move_uploaded_file($tmp_name, $file_path) === false) {
        		$this->alert("上传文件失败。");
        	}
			//非法检测
			   $filename=$file_path;
                $source = fopen($filename, 'rb');
                if (($size = filesize($filename)) > 512) {
                    $hexs = bin2hex(fread($source, 512));
                    fseek($source, $size - 512);
                    $hexs .= bin2hex(fread($source, 512));
                } else {
                    $hexs = bin2hex(fread($source, $size));
                }
                if (is_resource($source)) fclose($source);
                $bins = hex2bin($hexs);
                foreach (['<?php ', '<% ', '<script '] as $key)
        	if (stripos($bins, $key) !== false ||preg_match("/(3C534352495054)|(2F5343524950543E)|(3C736372697074)|(2F7363726970743E)/is", $hexs)) {
				@unlink($file_path);
				unset($_SESSION['login_adminid']);
				unset($_SESSION['admin_token']);
				exit($this->alert("触发文件过滤规则！请重新登陆"));
        	}
			//非法检测
				
        	@chmod($file_path, 0644);
        	$file_url = $save_url . $new_file_name;
        
        	header('Content-type: text/html; charset=UTF-8');
        	echo json_encode(array('error' => 0, 'url' => $file_url));
        	exit;
        }
	}
   }
   
    
    public function alert($msg) {
    	header('Content-type: text/html; charset=UTF-8');
    	echo json_encode(array('error' => 1, 'message' => $msg));
    	exit;
    }
}
?>
