<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;

use BL\app\libs\Controller;

class login extends CheckAdmin
{
    public function index()
    {
		 if (!file_exists(WEB_ROOT . '/upload/install.lock'))
        {
            $data['ctime'] = date('Y-m-d',time());
            $data['siteurl'] = $this->urlbase.$this->url_host;
            $this->model()->from('config')->updateSet($data)->where(array('fields' => 'id=?', 'values' => array('1')))->update();
            @file_put_contents(WEB_ROOT . '/upload/install.lock', 1);
        }
        $datas = array('title' => '管理登录');
        $this->put('login.php', $datas);
    }
    public function sigin()
    {
        $username = $this->req->post('username');
        $password = $this->req->post('password');
        $chkcode = $this->req->post('chkcode');
        if ($username == '' || $password == '' || $chkcode == '') {
            echo json_encode(array('status' => 0, 'msg' => '选项填写不完整'));
            exit;
        }
        if (!$this->session->get('chkcode') || $this->session->get('chkcode') != strtolower($chkcode)) {
            echo json_encode(array('status' => 0, 'msg' => '验证码填写错误'));
            exit;
        }
        if ($user = $this->model()->select()->from('admin')->where(array('fields' => 'adminname=?', 'values' => array($username)))->fetchRow()) {
            $ip = isset($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
            if ($user['is_limit_ip'] && strpos($user['limit_ip'], $ip) === false) {
                echo json_encode(array('status' => 0, 'msg' => '登录IP无效'));
                exit;
            }
            if ($user['adminpass'] == sha1($password)) {
				$admin_token=md5($ip);						
                $this->session->set('admin_token', $admin_token);
                $this->session->set('login_adminid', $user['id']);
                $this->session->set('login_adminname', $username);
                $data = array('adminid' => $user['id'], 'addtime' => time(), 'ip' => $ip);
                $this->model()->from('adminlogs')->insertData($data)->insert();
                echo json_encode(array('status' => 1, 'msg' => '登录成功', 'url' => $this->dir));
                exit;
            }
        }
        echo json_encode(array('status' => 0, 'msg' => '账号或密码不正确'));
        exit;
    }
    public function logout()
    {
        if ($this->req->session('login_adminname')) {
            $_SESSION['login_adminname'] = '';
            unset($_SESSION['login_adminname']);
        }
        if ($this->req->session('login_adminid')) {
            $_SESSION['login_adminid'] = '';
            unset($_SESSION['login_adminid']);
        }
        if ($this->req->session('admin_token')) {
            $_SESSION['admin_token'] = '';
            unset($_SESSION['admin_token']);
        }
      $this->res->redirect($this->dir . 'login');
    }
}