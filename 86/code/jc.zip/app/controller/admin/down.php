<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;

use BL\app\libs\Controller;
use BL\app\model\KamiModel;

class down extends CheckAdmin
{
    public function index()
    {
        $gid = $this->req->get('gid')?$this->req->get('gid'):-1;//商品id
        $kano = $this->req->get('kano') ;
        $cons = '';
        $consArr = [];
        if($gid > 0){
            $cons .= $cons ? ' and ' : '';
            $cons.= 'k.gid = ?';
            $consArr[] = $gid;
        }
        if($kano != ""){
            $cons .= $cons ? ' and ' : '';
            $cons.= 'k.kano = ?';
            $consArr[] = $kano;
        }
        $lists = [];
        $page = $this->req->get('p');
        $page = $page ? $page : 1;
        $pagesize = 20;
        $totalsize = $this->model()->from('down k')->where(array('fields' => $cons, 'values' => $consArr))->count();
        if ($totalsize) {
            $totalpage = ceil($totalsize / $pagesize);
            $page = $page > $totalpage ? $totalpage : $page;
            $offset = ($page - 1) * $pagesize;
            $lists = $this->model()->select('k.*,g.gname')->from('down k')->limit($pagesize)->left('goods g')->on('k.gid=g.id')->join()->offset($offset)->where(array('fields' => $cons, 'values' => $consArr))->orderby('k.id desc')->fetchAll();
        }
        $pagelist = $this->page->put(array('page' => $page, 'pagesize' => $pagesize, 'totalsize' => $totalsize, 'url' => '?gid='.$gid.'&kano='.$kano.'&p='));
        $class = $this->model()->select()->from('goods')->where(array('fields' => 'type = 2'))->fetchAll();
        $search =[
            'gid' => $gid,
            'kano' => $kano,
            'is_ste' => $is_ste
        ];

        $data = array('title' => '下载列表', 'lists' => $lists, 'class' => $class,'pagelist' => $pagelist, 'search' => $search);
        $this->put('down.php', $data);

    }

    
    public function save()
    {
        $data = array();
        if (isset($_POST)) {
            foreach ($_POST as $key => $val) {
                if ($key != 'gid' && $key != 'kano') {
                    $data[$key] = $this->req->post($key);
                }
            }
        }
        $kano = $this->req->post('kano');
        $gid = $this->req->post('gid');
        if ($kano == '' || $gid == '') {
            echo json_encode(array('status' => 0, 'msg' => '选项填写不完整'));
            exit;
        }
        if ($this->model()->select()->from('down')->where(array('fields' => 'gid=?', 'values' => array($gid)))->count()) {
            echo json_encode(array('status' => 0, 'msg' => $gid . ' 该商品已经有下载文件'));
            exit;
        } 
        $data = $_POST;
		
        if ($this->model()->from('down')->insertData($data)->insert()) {
			//随机增加库存
			$gdata['kuc'] = rand(100,998);
			$this->model()->from('goods')->updateSet($gdata)->where(array('fields' => 'id = ?', 'values' => array($gid)))->update();
			$this->res->redirect($this->dir . 'down');
            exit;
        }
		 $this->error('保存失败');
        exit;
    }
	
    public function delall()
    {
        $ids = $this->req->post('ids');
        $idsarr = explode(',',$ids);
        foreach ($idsarr as $id)
        {
            $this->del($id);
        }
        echo json_encode(array('status' => 1));exit;

    }

    public function del($cid = "")
    {
        $id = $cid? $cid : $this->req->get('id');
        if ($id) {
            $down = $this->model()->select()->from('down')->where(array('fields' => 'id=?', 'values' => array($id)))->fetchRow();
            if ($this->model()->from('down')->where(array('fields' => 'id = ?', 'values' => array($id)))->delete()) {
				  if($down && $down['is_ste'] == 0){
                    //减去库存
                    $gdata['kuc'] = 0;
                    $this->model()->from('goods')->updateSet($gdata)->where(array('fields' => 'id = ?', 'values' => array($down['gid'])))->update();
                }
				 if(!$cid){
                    echo json_encode(array('status' => 1));
                    exit;
                }
            }
        }
        if(!$cid) {
            echo json_encode(array('status' => 0));
            exit;
        }
    }

}