<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller\admin;
use BL\app\libs\Controller;

class wap extends CheckAdmin
{
    public function index()
    {
        $data = array('title' => '手机模板');
        $this->put('wap.php', $data);
    }
    public function save()
    {
        $data = array();
        if (isset($_POST)) {
            foreach ($_POST as $key => $val) {
                $data[$key] = $this->req->post($key);
            }
        }
        if ($data) {
            if ($this->req->get('t')) {
                $data['is_checkout_jump'] = isset($data['is_checkout_jump']) ? 1 : 0;
            }
            if ($this->model()->from('config')->updateSet($data)->update()) {
                echo json_encode(array('status' => 1, 'msg' => '设置保存成功'));
                exit;
            }
        }
        echo json_encode(array('status' => 0, 'msg' => '设置保存失败'));
        exit;
    }
}