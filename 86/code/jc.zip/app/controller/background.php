<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */
$url = 'http://wallpaper.apc.360.cn/index.php?c=WallPaper&a=getAppsByCategory&cid='.$_GET['cid'].'&start='.mt_rand(0, 100).'&count=1&from=360chrome';//360壁纸调取接口
if($_GET['cid']=="99"){
	$url = 'http://wallpaper.apc.360.cn/index.php?c=WallPaper&a=getAppsByOrder&order=create_time&start='.mt_rand(0, 100).'&count=1&from=360chrome';//最新 
}
$curl = curl_init();
$httpheader[] = "Accept:*/*";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
curl_setopt($curl, CURLOPT_HTTPHEADER, $httpheader);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_TIMEOUT, 60);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_URL, $url);
$bing_data = curl_exec($curl);
curl_close($curl);
$bing_arr=json_decode($bing_data,true);
if (!empty($bing_arr['data'][0]['url'])) {
        $data['code']=1;
        $data['url']=$bing_arr['data'][0]['url'];
}else{
        $data['code']=-1;
}

	@header('Content-Type: application/json; charset=UTF-8');
	exit(json_encode($data));

 ?>