<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */


namespace BL\app\controller;

use BL\app\libs\Controller;

class product extends Controller
{
    public function index()
    {
		$id = $this->req->get('id') ? $this->req->get('id') : $this->action[1];
        $pass = $this->req->get('pwd');
        $data = $this->model()->select()->from('goods')->where(array('fields' => 'id=?', 'values' => array($id)))->fetchRow(); 
      //if($data['pwd']&&$data['pwd']!=$pass)die("查看密码错误");//判断并验证密码查看
     	 if($this->session->get('login_lid')){
                $data['price'] = $data["money{$this->session->get('login_lid')}"];
              }else{
                $data['price'] =  $data['gmoney'] ;
              }
			   if($this->config['pcindex']==5){				   
					$this->put('product'.$this->config['pcindex'].'.php', $data);				   
			   }else{
					$this->put('product.php', $data);				   
			   }
    }}
