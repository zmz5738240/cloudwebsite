<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app\controller;

use BL\app\libs\Controller;

class buy extends Controller
{
    public function index()
    {
		$id = $this->req->get('id') ? $this->req->get('id') : $this->action[1];
        $pass = $this->req->get('pwd');
        $data = $this->model()->select()->from('goods')->where(array('fields' => 'id=?', 'values' => array($id)))->fetchRow(); 
      //if($data['pwd']&&$data['pwd']!=$pass)die("查看密码错误");//判断并验证密码查看
     	 if($this->session->get('login_lid')){
                $data['price'] = $data["money{$this->session->get('login_lid')}"];
              }else{
                $data['price'] =  $data['gmoney'] ;
              }
		   $this->put('buy.php', $data);
    }
	
	
 /**
     * 提交订单
     */
    public function postOrder()
    {
        if($this->config['gw_reg']&&!$this->session->get('login_id')) resMsg(0,null,'请登录以后再购买');
        $post = $this->getReqdata($_POST);
        $post['number'] = intval($post['number']);
        if($post['gid'] =="" || intval($post['number']) <=0 || $post['account'] == ""){
            resMsg(0,null,'充值账号、数量、商品不能为空，请仔细填写');
        }
        $goods = $this->model()->select()->from('goods')->where(array('fields' => 'id=?', 'values' => array($post['gid'])))->fetchRow();      
       if($this->session->get('login_lid')){
                $goods['price'] = $goods["money{$this->session->get('login_lid')}"];
              }else{
                $goods['price'] =  $goods['gmoney'] ;
              }
      
      
        if(!$goods || $goods['is_ste'] == 0) resMsg(0,null,'商品不存在或已下架');
        if($goods['kuc'] < $post['number'])resMsg(0,null,'哦豁~卖完了！请联系客服QQ：'.$this->config['qq'].'添加');
        /**
         * 自动发卡
         */
		$post['account'] = remove_xss($post['account']);
        if($goods['type'] != 1){
            if($post['chapwd'] == ""){
               // resMsg(0,null,'查询密码不能为空');
            }
            if(!filter_var($post['account'],FILTER_VALIDATE_EMAIL)){
                /*resMsg(0,null,'邮箱格式错误，未确保能够收到邮件提醒请仔细填写');*/
            }
            $orderid = $this->zdOrder($post,$goods);
        }else{
            $ripu = explode(',',$goods['gdipt']);
            $ctnum = $ripu[0] != "" ?count($ripu):0;
            if($ctnum >0){
                $post['ipu1'] = remove_xss($post['ipu1']);
                if(trim($post['ipu1']) == "")resMsg(0,null,$ripu[0].'不能为空');
            }
            if($ctnum >1){
				$post['ipu2'] = remove_xss($post['ipu2']);
                if(trim($post['ipu2']) == "")resMsg(0,null,$ripu[1].'不能为空');
            }
            if($ctnum >2){
				$post['ipu3'] = remove_xss($post['ipu3']);
                if(trim($post['ipu3']) == "")resMsg(0,null,$ripu[2].'不能为空');
            }
            if($ctnum >3){
				$post['ipu4'] = remove_xss($post['ipu4']);
                if(trim($post['ipu4']) == "")resMsg(0,null,$ripu[3].'不能为空');
            }
            $orderid = $this->sgOrder($post,$goods);

        }
	
	    if($post['paytype'] == "alipay"){
		    $html="/pay/index?id=".$orderid."&type=".$post['paytype']."&paycode=".$this->config['pay_alipay']; 
		}
       if($post['paytype'] == "wxpay"){
        	$html="/pay/index?id=".$orderid."&type=".$post['paytype']."&paycode=".$this->config['pay_wxpay']; 
		}
       if($post['paytype'] == "jhpay"){
        	$html="/pay/index?id=".$orderid."&type=".$post['paytype']."&paycode=".$this->config['pay_jhpay']; 
		}
      
        resMsg(999,$html,'下单成功，请支付！');

    }	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    public function sgOrder($data,$goods)
    {
    	unset($data['paytype']);
         if($goods['checks'] == 0){
            $check =[$data['account'],$goods['id']];
            //检测重复下单
            $order = $this->model()->select()->from('orders')->where(array('fields' => 'account = ? AND gid = ? AND ( `status` > 0 AND `status` <> 4  )', 'values' => $check))->fetchRow();
            if($order)resMsg(0,null,'本商品限制重复下单，一号一次');
        }
        $info = $goods['onetle'].':'.$data['account'];
        $ripu = explode(',',$goods['gdipt']);
        $index = 1;
        foreach ($ripu as $value){
            if($value!=""){
                $info.="<br/> ".$value.':'.remove_xss($data['ipu'.$index]);
                $index = $index+1;
            }
        }
 		$uid = $this->session->get('login_id') ? $this->session->get('login_id') : 0;//用户uid
 		$uname = $this->session->get('login_name') ? $this->session->get('login_name').'('.$this->session->get('login_gtitle').')' : "游客";//用户名
        $inadd = [
            'orderid' =>$this->res->getOrderID(),
            'oname' => $goods['gname'],
            'gid' => $goods['id'],
            'omoney' => $goods['price'],
            'onum' => $data['number'],
            'cmoney' => $goods['price'] * $data['number'],
            'chapwd' => $data['chapwd'],
            'account' => remove_xss($data['account']),
            'otype' => 1,
            'ctime' => time(),
            'status' => 0,
            'uid' => $uid,
            'uname' => $uname,
            'info' => $info
        ];
        $addres = $this->model()->from('orders')->insertData($inadd)->insert();
        if($addres){
            if($goods['price'] == 0){
                resMsg(2,null,'下单成功！');
            }
            return $inadd['orderid'];
        }
        resMsg(0,null,'下单失败！');

    }

    /**自动发卡
     * @param $data
     * @param $goods
     */
    private function zdOrder($data,$goods)
    {
    	unset($data['paytype']);
 		$uid = $this->session->get('login_id') ? $this->session->get('login_id') : 0;//用户uid
 		$uname = $this->session->get('login_name') ? $this->session->get('login_name').'('.$this->session->get('login_gtitle').')' : "游客";//用户名
        $inadd = [
            'orderid' =>$this->res->getOrderID(),
            'oname' => $goods['gname'],
            'gid' => $goods['id'],
            'omoney' => $goods['price'],
            'onum' => $data['number'],
            'cmoney' => $goods['price'] * $data['number'],
            'chapwd' => $data['chapwd'],
            'account' => remove_xss($data['account']),
            'otype' => $goods['type'],
            'ctime' => time(),
            'uid' => $uid,
            'uname' => $uname,
            'status' => 0
        ];
        $addres = $this->model()->from('orders')->insertData($inadd)->insert();
        if($addres){
            if($goods['price'] == 0){
                resMsg(2,null,'下单成功！');
            }
            return $inadd['orderid'];
        }
        resMsg(0,null,'下单失败！');

    }









}
