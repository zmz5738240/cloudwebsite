<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */

namespace BL\app;
class Config{
	static function db(){
		$db = require 'db.php';
		return $db;
	}

	static function systemInfo()
	{
		return [
			'version' => 'v5.3.2',
		];
	}

    public function getMailTpl(){
        return array(
            '卡密发送','管理员通知','库存告警','找回密码'
        );
    }



}
?>
