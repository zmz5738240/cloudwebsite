<?php
/**
 * @copyright   2008-2020 ���ַ��� <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   ���ַ���V3�������Զ�����ϵͳ��
 */

namespace BL\app\model;

use BL\app\Config;

class Retmsg
{
    function __construct()
    {
        $this->setConfig = new Config();
    }
    public function put($code, $data_type = false)
    {
        return $data_type ? json_encode(array('status' => $code, 'msg' => $this->setConfig->retMsg($code))) : $code . ',' . $this->setConfig->retMsg($code);
    }
}