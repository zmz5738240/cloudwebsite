<?php
/**
 * @copyright   2008-2020 伯乐发卡 <http://www.lailiyun.com>
 * @creatdate   2020-9-10 Mr wang <634273662@qq.com>
 * @version   伯乐发卡V3（个人自动发卡系统）
 */
error_reporting(0);
ini_set('display_errors','off');

define('BL_ROOT',dirname(__FILE__));
define("WEB_ROOT",realpath(dirname(__FILE__).'/../'));
ob_start();header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');
//自动加载
require BL_ROOT.'/../vendor/autoload.php';
require_once BL_ROOT.'/common.php';
require_once BL_ROOT.'/Config.php';
require_once BL_ROOT.'/blapp.php';
session_start();
?>