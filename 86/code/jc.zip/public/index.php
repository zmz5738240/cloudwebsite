<?php
error_reporting(0);
ini_set('display_errors','off');
if (!file_exists(__DIR__ . '/../data/install.lock'))
{
    require_once __DIR__.'/../data/install.php';
    exit;
}
if (file_exists(__DIR__ . '/../data/update.php'))
{
    require_once __DIR__.'/../data/update.php';
    exit;
}
require_once 'waf.php';
define('web_path',dirname(__FILE__));
require_once __DIR__.'/../app/init.php';
use BL\app\blapp;
$app = blapp::getInstance();
$app -> run();
?>