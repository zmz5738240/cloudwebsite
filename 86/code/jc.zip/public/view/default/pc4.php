<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
    <title><?php echo $this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
	<script src="<?php echo $this->config['cdnpublic']?>jquery/1.12.4/jquery.min.js"></script>
    <script src="/static/js/pajax.js"></script>
  <!--[if lt IE 9]>
    <script src="<?php echo $this->config['cdnpublic']?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body id="bg">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
  <link href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="<?php echo $this->config['cdnpublic']?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
<style>
body{
background-color:#c1c4ce;}
.panel{
	background-color: #ffffff8f!important;
}
.list-group-item{
	background-color: #ffffffab!important;
}
</style>
<div class="modal fade" align="left" id="myModal" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $this->config['sitename']?></h4>
      </div>
      <div class="modal-body">
	  <p>
<?php echo $this->config['tips'] ?>
<div class="btn-group btn-group-justified">
<a target="_blank" class="btn btn-info" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes"  pjax="exclude"><i class="fa fa-qq"></i> 联系客服</a>
 <?php if($this->session->get('login_name')) { ?>
 <a target="_blank" class="btn btn-warning" href="javascript:;" onclick="repwd()"><i class="fa fa-users"></i>修改密码</a>			  
<a target="_blank" class="btn btn-danger" href="/user"><i class="fa fa-cloud-download"></i> 会员中心</a>
           <?php }else{ ?>		   
<a target="_blank" class="btn btn-warning" href="/login"><i class="fa fa-users"></i>登录</a>			  
<a target="_blank" class="btn btn-danger" href="/reg"><i class="fa fa-cloud-download"></i> 注册</a>
<?php } ?> 			  

</div></p>     


 </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">知道了</button>
      </div>
    </div>
  </div>
</div>

<div class="navbar navbar-default navbar-fixed-top affix" role="navigation">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only"><?php echo $this->config['sitename']?></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="./"><?php echo $this->config['sitename']?></a>
	<p class="navbar-text pull-left text-muted hidden-xs hidden-sm"><small class="text-muted text-sm"><em><?php echo $this->url_host;?></em></small></p>
  </div>
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
	  <li class="active"><a href="./"><span class="glyphicon glyphicon-home"></span>&nbsp;下单首页</a></li>
	  <li class=""><a href="/chaka"><span class="glyphicon glyphicon-search"></span>&nbsp;查询订单</a></li>
	    </div>
  </div>
</div>
  
<div class="container" style="margin-top: 60px">
 
<div class="row">
       <div class="col-md-12">
<div class="panel panel-primary">
    <div class="panel-heading" align="center">
        <h3 class="panel-title"><a data-toggle="collapse" href="#collapseA">公告</a></h3>
    </div>
<div id="collapseA" class="panel-collapse collapse in">
<p>
<?php echo $this->config['tips'];
if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";}
?>
<div class="btn-group btn-group-justified">
<a target="_blank" class="btn btn-info" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes"  pjax="exclude"><i class="fa fa-qq"></i> 联系客服</a>
<?php if($this->session->get('login_name')) { ?>
 <a target="_blank" class="btn btn-warning" href="javascript:;" onclick="repwd()"><i class="fa fa-users"></i>修改密码</a>			  
<a target="_blank" class="btn btn-danger" href="/user"><i class="fa fa-cloud-download"></i> 会员中心</a>
<?php }else{ ?>		   
<a target="_blank" class="btn btn-warning" href="/login"><i class="fa fa-users"></i>登录</a>			  
<a target="_blank" class="btn btn-danger" href="/reg"><i class="fa fa-cloud-download"></i> 注册</a>
<?php } ?> 
</div></p> </div>
</div>
       </div>
</div>

<div class="row">


<?php foreach($class as $vals):?>
<div class="col-md-4">
<div class="panel panel-primary">
    <div class="panel-heading" align="center">
        <h3 class="panel-title"><a data-toggle="collapse" href="#collapse<?php echo $val['id'] ;?>" ><?php echo $vals['title'];?></a></h3>
    </div>
	<div id="collapse<?php echo $val['id'] ;?>" class="panel-collapse collapse in">
        <table class="table table-bordered table-striped">     
          <tbody>
		   <?php foreach ($lists as $val): ?>
						   <?php if ($vals['id']==$val['cid']){ ?>
					<tr>
					<td><?php echo $val['gname']?></td>
					<td align="center"><font color="#ff3333"><b><?php echo $val['price']?></b></font>元<font color="#ff3333">1</font>个</td>
					<td align="center"><a href="<?php echo  "http://".$this->url_host.$producturl.$val['id']; ?>" class="btn 
					<?php if($val['type']==0){
						echo 'btn-success btn-xs" style="background:#4faf1b">自动发卡';
						
					}else if($val['type']==1){
						echo 'btn-danger btn-xs" style="background:#ff803a">自动充值';
					}else{	
						echo 'btn-warning btn-xs" style="background:#FF4351">资源下载';
					}?> </a></td>
					</tr>   
			<?php }?>  
			<?php endforeach;?>
			</tbody>
        </table>
	</div>
</div>
	</div>
<?php endforeach;?>	
	
	
	
	
	
	
</div>

<p style="text-align:center"><span style="font-weight:bold;color:#fff;"><?php echo $this->config['copyright']?> <?php echo $this->config['icpcode']?'  <a style="font-weight:bold;color:#fff;" href="https://beian.miit.gov.cn" target="_blank" rel="noreferrer nofollow">'.$this->config['icpcode'].'</a>  ':''         
;?> <?php echo $this->config['stacode']?></span></p>
<script src="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $this->config['cdnpublic']?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>

<script type="text/javascript">
var isModal=true;
var homepage=true;
if( !$.cookie('op') && isModal==true){
	$('#myModal').modal({
		keyboard: true
	});
	var cookietime = new Date(); 
	cookietime.setTime(cookietime.getTime() + (60*60*1000));
	$.cookie('op', false, { expires: cookietime });
}
</script>

<script src="/static/default/js/app.js"></script>

<?php echo $this->bgrand();?>
<?php echo $this->config['stacode']?>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>