<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
	<script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body id="bg">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<link href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/static/default/assets/css/admin.css">
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
    <style type="text/css"> 
  	.am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default .am-footer-miscs{
		color: #fff;
	}
        .am-container{
          max-width: 1200px;
        }
    
        /* 色调设置 */
       .good-trade{
             background-color: #fff;
        }
		.sy-form{
				background-color: #fff;				
		}
		.floatfl{
			    text-align: center!important;
			float:left!important;
		}
    </style>
  <header class="am-topbar am-topbar-inverse am-header-fixed">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav ">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank"  pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout"  pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>	
    <form action="//<?php echo $this->url_host;?>" method="get" class="am-topbar-form am-topbar-left am-form-inline sy-form" role="search">
      <div class="am-form-group">
        <input type="text" name="gname" class="am-form-field am-input-sm" placeholder="搜索">
      </div>
    </form>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li><a href="/chaka"><span class="am-icon-search"></span>订单查询</a></li>
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>
  </div>
</div>
</header>
<div class="am-topbar"></div>
<div class="tpl-page-container tpl-page-header-fixed">
    <div class="am-container">
        <div class="tpl-content-scope">
            <div class="notefk note-info">
                <?php echo $this->config['tips'] ?>
            </div>
        </div>

        <div class="row">

            <div class="am-u-md-6 am-u-sm-12 row-mb">
                <div class="tpl-portlet">
                    <div class="tpl-portlet-title">
                        <div class="tpl-caption font-green ">
                            <i class="am-icon-shopping-bag"></i>
                            <span>购买商品</span>
                        </div>

                    </div>

                    <div class="tpl-scrollable">
                        <div class="am-g tpl-amazeui-form">


                            <div class="am-u-sm-12 ">
                                <form class="am-form am-form-horizontal" id="sgform">
                                    <div class="am-form-group">
                                        <label for="sc-cid" class="am-u-sm-3 am-form-label">分类</label>
                                        <div class="am-u-sm-9">
                                            <select id="sc-cid" class="am-form-field am-round">
                                                <option value="0">请选择分类</option>
                                                <?php if($class):?>
                                                    <?php foreach($class as $key=>
                                                                  $val):?>
                                                        <option value="<?php echo $val['id']?>">
                                                            <?php echo $val['title']?>
                                                        </option>
                                                    <?php endforeach;?>
                                                <?php endif;?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="am-form-group">
                                        <label for="glist" class="am-u-sm-3 am-form-label">列表</label>
                                        <div class="am-u-sm-9">
                                            <select class="am-form-field am-round" id="glist">
                                                <option value="0">请选择商品</option>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="am-form-group">
                                        <label for="money" class="am-u-sm-3 am-form-label">单价</label>
                                        <div class="am-u-sm-9">
                                            <input type="text" id="money" class="am-form-field am-round"
                                                   disabled="disabled" value="">
                                        </div>
                                  </div>

                                    <div class="am-form-group">
                                        <label for="kuc" class="am-u-sm-3 am-form-label">库存</label>
                                        <div class="am-u-sm-9">
                                            <input type="text" id="kuc" class="am-form-field am-round"
                                                   disabled="disabled" value="">
                                        </div>
                                    </div>


                                    <div class="am-form-group">
                                        <label for="number" class="am-u-sm-3 am-form-label">数量</label>
                                        <div class="am-u-sm-9">
                                            <input id="number" class="am-form-field am-round" type="text" value="1">
                                        </div>
                                    </div>
                                    
                               
                                        <div class="am-form-group">
                                            <label class="am-u-sm-3 am-form-label">支付</label>
                                        	<?php if($this->config['pay_wxpay']!="0"){ ?>
                                            <label class="am-radio-inline">
                                                <input type="radio"  value="wxpay" name="pay_type" checked=""><img src="/static/pay/weixin.png" height="30px" title="微信支付">
                                              </label>
                                            <?php }  if($this->config['pay_jhpay']!="0"){ ?>
                                              <label class="am-radio-inline">
                                                <input type="radio" value="jhpay" name="pay_type" checked=""><img src="/static/pay/jhpay.png" height="30px"  title="聚合支付">
                                              </label>
                                            <?php }  if($this->config['pay_alipay']!="0"){ ?>
                                              <label class="am-radio-inline">
                                                <input type="radio" value="alipay" name="pay_type" checked=""><img src="/static/pay/alipay.png" height="30px"  title="支付宝支付">
                                              </label>
                                            <?php } ?>
                                        </div>
                                    
                                    <div class="am-form-group" id="okshop">

                                        <div class="am-u-sm-12 am-u-sm-push-5">
                                            <a onclick="okOrder()" class="am-btn am-btn-primary">确认购买</a>
                                        </div>

                                    </div>


                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


            <div class="am-u-md-6 am-u-sm-12 row-mb">
                <div class="tpl-portlet">
                    <div class="tpl-portlet-title">
                        <div class="tpl-caption font-red ">
                            <i class="am-icon-credit-card-alt"></i>
                            <span>商品详情</span>
                        </div>
                        <div class="actions">

                        </div>
                    </div>
                    <div class="tpl-scrollable">
                        <div class="am-g tpl-amazeui-form">


                            <div class="am-u-sm-12 " id="gdinfo">

                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="am-u-md-6 am-u-sm-12 row-mb">


                </div>
                <div class="am-u-md-6 am-u-sm-12 row-mb">

                </div>
            </div>


        </div>		
      
      
      


</div>
</div>


 

<?php 
$id=$this->req->get('id');
$cid=$this->req->get('cid');
$pwd=$this->req->get('pwd');
if($cid) {
		echo"<script>";
		echo "$.ajax({
		url: '/index/typegd',
		type: 'POST',
		dataType: 'json',
		data: {cid: ".$cid."},
		beforeSend: function () {
		$('#glist').html();
		},
		success: function (result) {	
		$('#glist').html(\"<option value='0'>请选择商品</option>\"+result.html);	";
		$optionxz = "$(&quot;#sc-cid option[value='$cid']&quot;).attr(&quot;selected&quot;,&quot;selected&quot;);
			   $(&quot;#glist option[value='$id']&quot;).attr(&quot;selected&quot;,&quot;selected&quot;);";					 
			echo htmlspecialchars_decode($optionxz, ENT_COMPAT);
		if($pwd){					
			echo" getGoodsInfo(".$id.",".$pwd.")";	
		}else{
			echo" getGoodsInfo(".$id.")";
		}
		echo "}
		});";
		echo"</script>";
}
?>
<footer data-am-widget="footer"
          class="am-footer am-footer-default"
          data-am-footer="{  }">
    <div class="am-footer-switch">
        友情链接：
	<?php 
	$link = $this->links;
	if($link):?>
	<?php foreach($link as $key=>
	$val):?>
	<span class="am-footer-divider"> | </span>
	<a class="am-footer-desktop" href="<?php echo $val['url']?>" target="_blank">
	<?php echo $val['title']?>
	</a>
	<?php endforeach;?>
	<?php endif;?>
    </div>
    
    <div class="am-footer-miscs ">
      <p><?php echo $this->config['copyright']?></p>
      <p><?php echo $this->config['icpcode']?'  <a href="https://beian.miit.gov.cn" target="_blank" rel="noreferrer nofollow">'.$this->config['icpcode'].'</a>  ':''         
;?></p>
      <p><?php echo $this->config['tel']?></p>
    </div>
  </footer>

  <div id="am-footer-modal"
       class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
    <div class="am-modal-dialog">
      <div class="am-modal-hd am-modal-footer-hd">
        <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
      </div>
      <div class="am-modal-bd">
		<?php echo $this->config['copyright']?>
		<?php echo $this->config['icpcode']?'  <a href="https://beian.miit.gov.cn" target="_blank" rel="noreferrer nofollow">'.$this->config['icpcode'].'</a>  ':''         
;?>
		<?php echo $this->config['tel']?>
	
      </div>
    </div>
  </div>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
<?php echo $this->bgrand();?>
<?php echo $this->config['stacode']?>

</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>