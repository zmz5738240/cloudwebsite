<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="zh-cn">
    <meta name="apple-mobile-web-app-capable" content="no"/>
    <meta name="apple-touch-fullscreen" content="yes"/>
    <meta name="format-detection" content="telephone=no,email=no"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="white">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-control" content="no-cache">
    <meta http-equiv="Cache" content="no-cache">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>订单:<?php echo $data['order']['orderid']; ?>付款 </title>
 <link href="../../static/pay/css/pay1.css" type="text/css" rel="stylesheet">
<body>
<div class="body">    
    <h1 class="mod-title">
        <span class="ico_log ico-2"></span>
    </h1>
    <div class="mod-ct">
        <div class="order">
        </div>
        <div class="amount">￥<?php echo $data['order']['cmoney']; ?></div>
        <div class="qrcode-img-wrapper" >
      		 <img  id="show_qrcode" class="show_qrcode" width="300" height="210" src="../../qrcode?size=210&text=<?php echo urlencode(@$data['str']); ?>" >
 			<div id="qrcode"></div>
                    <canvas id="imgCanvas" width="310" height="270"></canvas>
                </div>
  
              <div class="time-item" style = "padding-top: 10px">
                    <div class="time-item" id="msg"><h1>商品：<?php echo $data['order']['oname'];?></h1> </div>
               		 <div class="time-item"><h1>订单:<?php echo $data['order']['orderid']; ?></h1> </div>
                      <strong id="hour_show">0时</strong>
                      <strong id="minute_show">5分</strong>
                      <strong id="second_show">0秒</strong>
                </div>
      
      
          <div class="tip">
            <div class="ico-scan"></div>
            <div class="tip-text">
                <p id="showtext">打开微信 [扫一扫]</p>
            </div>
        </div>
    </div>
    <div class="foot">
        <p id="showtext"><?php echo $this->config['payinfo']?></p>
    </div>
</div>
<div style="width:720px;height:380px;display:none;">
    <div id="video-dialog"></div>
    <a href="javascript:void(0);" onclick="return false;" style="position:absolute;right:-25px;top:-20px;"
       id="close_video_btn" class="ico-video-close"></a></div>
<script src="<?php echo $this->config['cdnpublic']?>jquery/2.2.4/jquery.min.js"></script>  
<script src="<?php echo $this->config['cdnpublic']?>jquery.qrcode/1.0/jquery.qrcode.min.js"></script>
<script>
	var myTimer;
    var intDiff=1;
    function timer(intDiff) {
        myTimer = window.setInterval(function () {
            var day = 0,
                hour = 0,
                minute = 0,
                second = 0;//时间默认值
            if (intDiff > 0) {
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            $('#hour_show').html('<s id="h"></s>' + hour + '时');
            $('#minute_show').html('<s></s>' + minute + '分');
            $('#second_show').html('<s></s>' + second + '秒');
            if (hour <= 0 && minute <= 0 && second <= 0) {
				intDiff = 0;
                $('#show_qrcode').attr("src","../../static/pay/images/qrcode_timeout.png");  
                clearInterval(myTimer);
            }
            intDiff--;
            
        }, 2000);
    }
   
  
   $().ready(function(){
      timer("300");
      var qrcode = $('#qrcode').qrcode({  
            text: '<?php echo @$data['str']; ?>',  
            width: 200,  
            height: 200,
        }).hide();  
        //添加文字  
        var outTime = '过期时间：<?php echo date('Y-m-d H:i:s',strtotime("+5 minute")); ?>';//过期时间
        var canvas = qrcode.find('canvas').get(0);  
        var oldCtx = canvas.getContext('2d');  
        var imgCanvas = document.getElementById('imgCanvas');  
        var ctx = imgCanvas.getContext('2d');  
        ctx.fillStyle = 'white';  
        ctx.fillRect(0,0,310,270);  
        ctx.putImageData(oldCtx.getImageData(0, 0, 200, 200), 55, 28);  
        ctx.textBaseline = 'middle';  
        ctx.textAlign = 'center';  
        ctx.font ="15px Arial";  
        ctx.fillStyle = '#00c800';
        ctx.strokeStyle = '#00c800'
        ctx.fillText(outTime, imgCanvas.width / 2, 242 );  
        ctx.strokeText(outTime, imgCanvas.width / 2, 242);  

        var about = '过期后请勿支付，不自动到账'; 
        ctx.fillText(about, imgCanvas.width / 2, 260 );  
        ctx.strokeText(about, imgCanvas.width / 2, 260);  

        imgCanvas.style.display = 'none';  
        $('#show_qrcode').attr('src', imgCanvas.toDataURL('image/png')).css({  
            width: 310,height:270  
        }); 
     
      <?php //判断二维码失效没
        if(empty(@$data['str'])){
          echo '$(".show_qrcode").attr("src","../../static/pay/images/qrcode_timeout.png"); ';
          echo ' $(".tip").remove();                    $("#hour_show").remove();       $("#minute_show").remove();       $("#second_show").remove(); ';
          }  
      ?>
  });
     
    // 检查是否支付完成
    function loadmsg() {
	 if(intDiff>0){
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "getshop.php",
            timeout: 10000, //ajax请求超时时间10s
            data: {oid: "<?php echo $data['order']['orderid']; ?>"}, //post数据
            success: function (data, textStatus) {
                //从服务器得到数据，显示数据并继续查询
                if (data.status == 1) {
                    alert('支付成功，点击跳转中...');
                    window.location.href = data.data;
                } else {
                    setTimeout("loadmsg()", 4000);
                }
            },
            //Ajax请求超时，继续查询
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (textStatus == "timeout") {
                    setTimeout("loadmsg()", 1000);
                } else { //异常
                    setTimeout("loadmsg()", 4000);
                }
            }
        });
		}
    }

    window.onload = loadmsg();
</script>
</body>
</html>