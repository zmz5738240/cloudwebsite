<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $data['gname'].'_'.$this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
	<script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body id="bg">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<link href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/static/default/assets/css/admin.css">
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
    <style type="text/css">
	.am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default .am-footer-miscs{
		color: #fff;
	}
        .am-container{
          max-width: 1200px;
        }
    
        /* 色调设置 */
       .good-trade{
             background-color: #fff;
        }
		.sy-form{
				background-color: #fff;				
		}
		.floatfl{
			    text-align: center!important;
			float:left!important;
		}
		
       
    </style>
  <header class="am-topbar am-topbar-inverse am-header-fixed">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav ">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank" pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout" pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>	
    <form action="//<?php echo $this->url_host;?>" method="get" class="am-topbar-form am-topbar-left am-form-inline sy-form" role="search">
      <div class="am-form-group">
        <input type="text" name="gname" class="am-form-field am-input-sm" placeholder="搜索">
      </div>
    </form>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li><a href="/chaka"><span class="am-icon-search"></span>订单查询</a></li>
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>
  </div>
</div>
</header>
<div class="am-topbar"></div>
  <script src="/static/common/layer/layer.js"></script>
  <script src="/static/default/assets/js/app.js"></script>
  <script src="/static/default/js/app.js"></script>
  <?php
  if($data['pwd']&&$data['pwd']!=$this->req->get('pwd')){
  echo "<script>    
         layer.prompt({title: '请输入商品密码', formType: 1}, function (pass, index) {
            layer.close(index);
            if (pass == '') {
                layer.alert('请输入商品密码', {icon: 2});
                return;
            }
            gpwd = pass
	  $.ajax({
        url: '/index/getGoodsInfoajax',
        type: 'POST',
        dataType: 'json',
        data: {id: ".$data['id'].",pass:gpwd},
        beforeSend: function () {
            layer.load(1);
        },
        success: function (result) {
            layer.closeAll();
            if (result.status == 0) {
                layer.alert('查询失败', {icon: 2})
            } else {              
          		window.location.href='product?id=".$data['id']."&pwd='+gpwd           
              			}
              }
          });
          
        });        
    </script> ";
      unset($data);
  }
  ?>
  

      <div class="am-container" style="padding:2px">
        

<div class="good-trade">
        <div class="am-container" style="">
                        <div class="am-g ">
                            
                          <div class="am-u-sm-12 am-u-md-5 am-u-lg-5 trade-goodimg am-u-end" style="padding: 0px;text-align: center">
                                       
                                                        <img src="<?php echo $data['image'];?>" >
                                                 
                          </div>
                          <div class="am-u-sm-12 am-u-md-7 am-u-lg-7  am-u-end">
                                  <!-- 网格开始 -->
                                 
                                                
                                                <h2 style="margin-top: 0px;color: #333;font-family: 微软雅黑;" class="am-text-truncate"><?php echo $data['gname'];?></h2>
                                                <p class="trade-goodinfo" style="background-color:#f5f3ef;margin-top: 20px">
                                                        <span style="color:#6c6c6c">促销：</span>
                                                        <span class="trade-price"><?php echo $data['price'];?></span>
                                                  		<span style="color:#6C6C6C">库存：<?php echo $data['kuc'];?>件</span>
                                                                                                           
                                                </p>    
											

				
                            <div class="am-form am-form-horizontal">							
                                  <div class="am-form-group ajaxdiv">
                                      <label for="number" class="am-u-sm-2 am-form-label">数量:</label>
                                        <div class="am-u-sm-2 floatfl">
                                          <input type="hidden" value="<?php echo $data['id'];?>"  id="glist" name="gid">
                                            <input type="number" id="number" name="number" min="1" max="10000" value="1" class="othbox am-form-field am-radius"  pattern="^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$" required="required">
                                        </div>
									</div>
                            
                          <?php  
                            
                                    //判断是否是自动发卡
        if ($data['type'] != 1) {
            $html = "<div class=\"am-form-group ajaxdiv\">
                                      <label for=\"account\" class=\"am-u-sm-2 am-form-label\">联系方式:</label>
                                        <div class=\"am-u-sm-10 floatfl\">
                                            <input type=\"text\" id=\"account\" class=\"am-form-field am-radius\"
                                                 placeholder=\"QQ号码或者电话\"   value=\"".$this->session->get('login_uemail')."\">
												 
                                        </div>
                     </div>";

        }else{
            //手工订单
            $html = "<div class=\"am-form-group ajaxdiv\"><label for=\"account\" class=\"am-u-sm-2 am-form-label\">".$data['onetle'].":</label>
                                        <div class=\"am-u-sm-10 floatfl\">
                                            <input type=\"text\" id=\"account\" class=\"am-form-field am-radius\"
                                                    value=\"\">
                                        </div>
                     </div>";
            $ripu = explode(',',$data['gdipt']);
            if($ripu[0]){
                $ipu = 1;
                foreach ($ripu as $v){
                    $html.="<div class=\"am-form-group ajaxdiv\"><label for=\"ipu".$ipu."\" class=\"am-u-sm-2 am-form-label\">".$v.":</label>
                                        <div class=\"am-u-sm-10 floatfl\">
                                            <input type=\"text\" id=\"ipu".$ipu."\" class=\"am-form-field am-radius\"
                                                    value=\"\">
                                        </div>
                     </div>";
                    $ipu = $ipu+1;
                }

            }
        }
                            
                            echo $html;
                            ?>
                               
                               
                            <div class="am-form-group ajaxdiv">
                                <label class="am-u-sm-2 am-form-label">支付方式:</label>
                            	<?php if($this->config['pay_wxpay']!="0"){ ?>
                                <label class="am-radio-inline">
                                    <input type="radio"  value="wxpay" name="pay_type" checked=""><img src="/static/pay/weixin.png" height="30px" title="微信支付">
                                  </label>
                                <?php }  if($this->config['pay_jhpay']!="0"){ ?>
                                  <label class="am-radio-inline">
                                    <input type="radio" value="jhpay" name="pay_type" checked=""><img src="/static/pay/jhpay.png" height="30px"  title="聚合支付">
                                  </label>
                                <?php }  if($this->config['pay_alipay']!="0"){ ?>
                                  <label class="am-radio-inline">
                                    <input type="radio" value="alipay" name="pay_type" checked=""><img src="/static/pay/alipay.png" height="30px"  title="支付宝支付">
                                  </label>
                                <?php } ?>
                            </div>
    
                            </div>
                                               
                                               <br>
                                                <button type="submit" class="am-btn am-btn-primary am-btn-xl am-square am-center" onclick="okOrder()" id="paysubmit"   title="<?php echo $this->config['payinfo'];?>"><span class="am-icon-shopping-cart"></span>立即购买</button>
                                                
                                               
                                <!-- 网格结束 -->
                          </div>
                        </div>
                      </div>


<div class="am-panel am-panel-default" style="border-radius:0px;margin-top: 10px">
                <div class="am-panel-hd">商品描述</div>
                <div class="am-panel-bd"><?php echo $data['cont'];?>
                                                </div>
              </div>
</div>



    </div>
  
    <footer data-am-widget="footer"
          class="am-footer am-footer-default"
           data-am-footer="{  }">
    <div class="am-footer-miscs ">
        <p><?php echo $this->config['copyright']?></p>
        <p><?php echo $this->config['icpcode']?></p>
        <p><?php echo $this->config['tel']?></p>
    </div>
  </footer>

  <div id="am-footer-modal"
       class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
    <div class="am-modal-dialog">
      <div class="am-modal-hd am-modal-footer-hd">
        <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
      </div>
      <div class="am-modal-bd">
		<?php echo $this->config['copyright']?>
		<?php echo $this->config['icpcode']?>
		<?php echo $this->config['tel']?>
	
      </div>
    </div>
  </div>
<script>
//自定页
<?php
 if(mb_strlen($data['noti'],"utf-8")>5){	
				echo "layer.open({
					  type: 1, 
					  title: '购买提醒',
					  skin: 'layui-layer-demo',
					  closeBtn: 0,
					  anim: 2,
					  shadeClose: true,
					  content: '".$this->jsformat($data['noti'])."',
					  btn: '我知道了'
					});"; 
	}  
?>
  
  
function countoper(oper){
        count=$("#count").val();
        if(oper=='jia'){
           count=parseInt(count)+1;
        }else{
           count=parseInt(count)-1;
        }
        if(parseInt(count)<0){
           count=0;
        }
         $("#count").val(count);
}

        
</script><?php echo $this->bgrand();?>
<?php echo $this->config['stacode'];?>
</main> 

  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>