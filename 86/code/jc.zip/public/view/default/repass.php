<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $data['title'].'-'. $this->config['sitename']; ?></title>
    <meta name="description" content="><?php echo $data['title'].'-'. $this->config['sitename']; ?>">
    <meta name="keywords" content="><?php echo $data['title'].'-'. $this->config['sitename']; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="/static/default/favico.ico" />
	<!--[if (gte IE 9)|!(IE)]><!--><script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script><!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>modernizr/2.8.3/modernizr.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.ie8polyfill.min.js"></script>
    <![endif]-->	
	<script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
    <script src="/static/js/pajax.js"></script>	
</head>
<body id="bg" data-type="login">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
     <script>
        $(document.body).attr('data-type','login')
    </script>
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<link rel="stylesheet" href="/static/default/reg/css/app.css">
    <style>
	.sy-form{
				background-color: rgba(255, 255, 255, 0.9);				
		}
		
  .am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
    </style>
<header class="am-topbar am-topbar-inverse">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=<?php echo $this->config['qq']?>&uin=&site=qq&menu=yes" target="_blank" pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout" pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>
	
	
    <form action="//<?php echo $this->url_host;?>" method="get" class="am-topbar-form am-topbar-left am-form-inline sy-form" role="search">
      <div class="am-form-group">
        <input type="text" name="gname" class="am-form-field am-input-sm" placeholder="搜索">
      </div>
    </form>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li><a href="/chaka"><span class="am-icon-search"></span>订单查询</a></li>
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>

  </div>
</div>
</header>


<div class="am-g tpl-g">

    <div class="tpl-login">
       

            <div class="tpl-login-title">找回密码</div>
             <div class="tpl-login-content">

            <span class="tpl-login-content-info">
                  1.请确保您的邮箱能正常收到邮件或检查垃圾箱<br>
                  2.如果您记不起用户名，请<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes"  style="color: #1AA093">联系客服</a>为您重置！
              </span>

            <div style="margin-top:20px"></div>
            <form class="am-form tpl-form-line-form form-ajax" action="/reg/dorepass" method="post">
                <div class="am-form-group">
                    <input type="email" name="email" class="tpl-form-input"  placeholder="邮箱账号" required>

                </div>

                <div class="am-form-group">
                    <input type="text" name="uname" class="tpl-form-input"  placeholder="用户名" required>
                </div>

                <div class="am-form-group">

                    <button type="submit" class="am-btn am-btn-success  am-btn-block tpl-btn-bg-color-success tpl-login-btn">立即找回</button>

                </div>
                <div class="am-form-group tpl-login-remember-me" style="float:right" >
                    <label for="remember-me">
                         <a href="/login"  style="color: #1AA093">想起密码了？点我登陆</a>
                    </label>
                </div> 
                
                
            </form>
        </div>

    </div>

</div>
<script src="/static/common/layer/layer.js"></script>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<?php echo $this->bgrand();?>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>