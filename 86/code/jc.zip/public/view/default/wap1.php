<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
	<script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body id="bg">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<link href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/static/default/assets/css/admin.css">
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
    <style type="text/css"> 
	.am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default .am-footer-miscs{
		color: #fff;
	}
        .am-container{
          max-width: 1200px;
        }
    
        /* 色调设置 */
       .good-trade{
             background-color: #fff;
        }
		.sy-form{
				background-color: #fff;				
		}
		.floatfl{
			    text-align: center!important;
			float:left!important;
		}
		
        /* 色调设置 */
       .liebiaocatname{         
      	 background-color:<?php echo $this->config['color'];?>;color:#fff;text-align:center
      }
       .wapcatname{         
      	 background-color:<?php echo $this->config['color']; if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";}?>;color:#fff;text-align:center
      }	  
       .liebiaocatname a{        
      	 color:#fff;
      }
       .am-footer-switch{     
      	 color:#fff;
	   }
       .am-footer-default a{     
      	 color:#fff;
	   }
	   .wapcatname a{         
      	 color:#fff;
      }
      .am-table {
        background-color:#fff;font-size:15px;border:#ccc solid 1px
      }
      .index_good_body:hover{
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
			z-index: 2;
        }
    </style>
  <header class="am-topbar am-topbar-inverse am-header-fixed">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav ">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank"  pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout" pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>	
    <form action="//<?php echo $this->url_host;?>" method="get" class="am-topbar-form am-topbar-left am-form-inline sy-form" role="search">
      <div class="am-form-group">
        <input type="text" name="gname" class="am-form-field am-input-sm" placeholder="搜索">
      </div>
    </form>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li><a href="/chaka"><span class="am-icon-search"></span>订单查询</a></li>
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>
  </div>
</div>
</header>
<div class="am-topbar"></div>

<div class="am-container" style="padding:2px">    
        <div class="am-panel am-panel-default" style="margin:5px 0 5px 0;border-radius: 0px">
      <div class="am-panel-bd "><?php echo $this->config['tips'];if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";} ?></div>
    </div>
   <div class="goods">
	  <div class="am-show-landscape">
		   <table class="am-table">
			  <thead>
				  <tr class="thhead">
					  <th style="text-align: left">商品标题</th>
					  <th style="text-align: center;width: 10%">单价</th>
					  <th style="text-align: center;width: 10%">库存</th>
					  <th style="text-align:center">操作</th>
				  </tr>
			  </thead>
			  <tbody>
				
						<?php foreach($class as $vals):?>
						  <tr><th colspan="4" class="liebiaocatname"><a href="?cid=<?php echo $vals['id'];?>"><b><?php echo $vals['title'];?></b></a></th></tr>
						   <?php foreach ($lists as $val): ?>
						   <?php if ($vals['id']==$val['cid']){ ?>
						   <tr>
							 <td><b><?php echo $val['gname']?></b></td>
							 <td style="text-align: center"><span style="font-size:13px;color:red"><?php echo $val['price']?>元</span></td>
							 <td style="text-align: center"><?php echo $val['kuc'] ?>件</td>
							 <input id="cp<?php echo $val['id']?>" data-pwd<?php echo $val['pwd']?> type="hidden">
							 <td style="text-align:center">
							   <a href="<?php echo  "//".$this->url_host.$producturl.$val['id']; ?>">
							   <button class="am-btn am-btn-default am-btn-xs am-text-secondary">
								 <span class="am-icon-shopping-cart"></span>购买
							   </button>
							  </a>
							 </td>
						   </tr>
						   <?php }?>
						   <?php endforeach;?>
						   <?php endforeach;?>
										
				</tbody>
		  </table>
		  </div>
					  
	<div class="am-show-portrait">
				<div class="am-container">
				  <div class="am-g">
					  <?php foreach($class as $vals):?>
                                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12" style="padding:2px">
                                  <a href="?cid=<?php echo $vals['id'];?>"><div style="background-color: #393D49;color: #fff;padding: 10px;text-align: center"><?php echo $vals['title'];?></div></a>
                                </div>
                                <?php foreach ($lists as $val): ?>
                  				 <?php if ($vals['id']==$val['cid']){ ?>
                                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12" style="margin-bottom: 5px;padding:2px">
                                  <div style="background-color: #fff;height: 80px">
                                    <div style="padding:5px">									
										<a href="<?php echo  "//".$this->url_host.$producturl.$val['id']; ?>"  style="color: #000;">
                                        <img class="am-radius" alt="<?php echo $val['gname']?>" src="<?php echo $val['image']?>" width="70" height="70" style="float: left" />
                                        <div class="am-text-truncate" style="margin-left: 15px;">
                                          <span style="margin-left: 5px"><?php echo $val['gname']?></span>
                                          <br>
                                          <div style="margin-top: 18px">
                                            <span class="am-badge am-badge-danger am-radius" style="margin-left: 5px">库存(<?php echo $val['kuc']?>)</span>
                                            <span style="color: #ff0000">
                                              <b>¥<?php echo $val['price']?></b>
                                            </span>
                                          </div>
                                        </div>
                                      </a>
                                    </div>
                                  </div>
                                </div>
                                
                   <?php }?>
                   <?php endforeach;?>
                   <?php endforeach;?>  
				</div>
			  </div>						  
			</div>
						  <?php echo $lists ? $pagelist : '' ?>
    </div>
    </div>
  <footer data-am-widget="footer"
          class="am-footer am-footer-default"
          data-am-footer="{  }">
    <div class="am-footer-switch">
        友情链接：
	<?php 
	$link = $this->links;
	if($link):?>
	<?php foreach($link as $key=>
	$val):?>
	<span class="am-footer-divider"> | </span>
	<a href="<?php echo $val['url']?>" target="_blank">
	<?php echo $val['title']?>
	</a>
	<?php endforeach;?>
	<?php endif;?>
    </div>
    
    <div class="am-footer-miscs ">
      <p><?php echo $this->config['copyright']?></p>
      <p><?php echo $this->config['icpcode']?></p>
      <p><?php echo $this->config['tel']?></p>
    </div>
  </footer>

  <div id="am-footer-modal"
       class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
    <div class="am-modal-dialog">
      <div class="am-modal-hd am-modal-footer-hd">
        <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
      </div>
      <div class="am-modal-bd">
		<?php echo $this->config['copyright']?>
		<?php echo $this->config['icpcode']?>
		<?php echo $this->config['tel']?>
	
      </div>
    </div>
  </div>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<?php echo $this->bgrand();?>
<?php echo $this->config['stacode']?>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>