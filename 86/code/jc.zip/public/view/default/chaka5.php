<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo '订单查询_'.$this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
    <meta charset="utf-8">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>    
    <script src="<?php echo $this->config['cdnpublic']?>jquery/3.2.1/jquery.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
	<script src="/static/default/js/app.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body>
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
    <!-- slick css -->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>slick-carousel/1.9.0/slick.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>slick-carousel/1.9.0/slick-theme.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/4.0.0-beta.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>prism/9000.0.1/themes/prism.min.css">
    <link rel="stylesheet" type="text/css" href="/static/gmpanel/themify-icons/themify-icons.css">
    <link rel="stylesheet" type="text/css" href="/static/gmpanel/style.css">
    <link rel="stylesheet" type="text/css" href="/static/gmpanel/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css" href="/static/gmpanel/pcoded-horizontal.min.css">	
	<link href="/static/gmpanel/gmpanel.css?v4.18" type="text/css" rel="stylesheet">
	<link href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
	<style type="text/css">
	.pcoded .pcoded-header{
	    background: <?php echo $this->config['color'];?> !important;
	}
	</style>
    <div class="theme-loader">
            <div class="loader-track">
    		   <svg version="1.1" id="L7" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"  viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
    			<path fill="<?php echo $this->config['color'];?>" d="M31.6,3.5C5.9,13.6-6.6,42.7,3.5,68.4c10.1,25.7,39.2,38.3,64.9,28.1l-3.1-7.9c-21.3,8.4-45.4-2-53.8-23.3  c-8.4-21.3,2-45.4,23.3-53.8L31.6,3.5z">
    				<animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite" />
    			</path>
    			<path fill="<?php echo $this->config['color'];?>" d="M42.3,39.6c5.7-4.3,13.9-3.1,18.1,2.7c4.3,5.7,3.1,13.9-2.7,18.1l4.1,5.5c8.8-6.5,10.6-19,4.1-27.7 c-6.5-8.8-19-10.6-27.7-4.1L42.3,39.6z">
    				<animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="1s" from="0 50 50" to="-360 50 50" repeatCount="indefinite" />
    			</path>
    			<path fill="<?php echo $this->config['color'];?>" d="M82,35.7C74.1,18,53.4,10.1,35.7,18S10.1,46.6,18,64.3l7.6-3.4c-6-13.5,0-29.3,13.5-35.3s29.3,0,35.3,13.5 L82,35.7z">
    				<animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite" />
    			</path>
    		</svg>
    		</div>
    </div>
    <div id="pcoded" class="pcoded">
        <div class="pcoded-container">
            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="<?php echo $this->config['siteurl']; ?>">
                            <img class="img-fluid" src="<?php echo $this->config['logo']?>" alt="<?php echo $this->config['sitename']?>" />
                        </a>
                        <a class="mobile-options">
                            更多 <i class="fa fa-ellipsis-v"></i>
                        </a>
                    </div>

                    <div class="navbar-container container-fluid">
                        <ul class="nav-right">
                            <li>
                                 <a href="#" data-toggle="modal" data-target="#search-Modal" target="_blank">
                                    <i class="fa fa-search"></i> 搜索宝贝
                                </a>
                            </li>
                            <li>
                                <a href="#" data-toggle="modal" data-target="#url-Modal" target="_blank">
                                    <i class="fa fa-opera"></i> 站点扫码
                                </a>
                            </li>
                            <li>
                                <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank">
                                    <i class="fa fa-commenting"></i> 联系客服
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $this->config['qqqun']?>" target="_blank">
                                    <i class="fa fa-comments"></i> 加入Q群
                                </a>
                            </li>
                            <li>
                                <a href="/chaka">
                                    <i class="fa fa-search"></i> 订单查询
                                </a>
                            </li>
							<?php if($this->session->get('login_name')) { ?>
							<li>
                                    <a href="javascript:;" onclick="repwd()">
                                         <i class="fa fa-user"></i> 修改密码
                                    </a>
                                </li>
								<li>
                                    <a href="/user">
                                         <i class="fa fa-user"></i> 会员中心
                                    </a>
                                </li>
						<?php }else{ ?>		

                                <li>
                                    <a href="/login">
                                         <i class="fa fa-user"></i> 登陆
                                    </a>
                                </li>
                                <li>
                                    <a href="/reg">
                                         <i class="fa fa-cloud-download"></i>注册
                                    </a>
                                </li>
						<?php } ?> 	
                            
                        </ul>

                    </div>
                </div>
            </nav>
            <div class="pcoded-main-container">
                
<div class="container">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
						<div class="tpl-content-scope">
							<div class="note note-info">
								<h3>注意：
									<span class="close" data-close="note"></span>
								</h3>
								<p><span class="label label-default">待处理:</span> 表示付款成功等待管理员处理
								</p>
								<p><span class="label label-info">已处理:</span> 表示订单正在处理中
								</p>
								<p><span class="label label-success">已完成:</span> 表示订单已经完成
								</p>
								<p><span class="label label-danger">【处理失败】或者【发卡失败】</span> 表示订单异常，请联系管理员处理
								</p>
							</div>
						</div>


						<div class="tpl-portlet-components">
							<div class="portlet-title">
								<div class="caption font-green bold">
									<span class="am-icon-code"></span> 订单查询
								</div>
								<div class="tpl-portlet-input tpl-fz-ml">

								</div>


							</div>
							<div class="tpl-block">
								<div class="am-g">
									<div class="am-u-sm-12 am-u-md-6">
										<div class="am-btn-toolbar">

										</div>
									</div>

									<div class="am-u-sm-12 am-u-md-3">
										<div class="am-form-group">
											<select id="otype" name="status" data-am-selected="{btnSize: 'sm'}">
												<option value="0">自动发卡</option>
												<option value="1">手工订单</option>
												<option value="2">下载资源</option>
											</select>
										</div>

									</div>


									<div class="am-u-sm-12 am-u-md-3">
										<div class="am-input-group am-input-group-sm">
											<input type="text" id="account" name="account" value="" placeholder="购买时预留的联系方式" required
												   class="am-form-field">
											<span class="am-input-group-btn">
							<button class="am-btn  am-btn-default am-btn-success tpl-am-btn-success am-icon-search"
									onclick="getOrders()"
									type="button"></button>
						  </span>
										</div>
									</div>

								</div>
								<div class="am-g">
									<div class="am-u-sm-12 am-scrollable-horizontal">

										<table class="am-table am-table-striped am-table-hover table-main" >
											<thead>
											<tr>

												<th class="table-id">订单id</th>
												<th class="table-set">操作</th>
												<th class="table-status">状态</th>
												<th class="table-oname">订单名称</th>
												<th class="table-otype">订单类型</th>
												<th class="table-onum">充值数量</th>
												<th class="table-omoney">商品单价</th>
												<th class="table-cmoney">订单总价</th>
												<th class="table-account">充值账号</th>
												<th class="table-paytype">支付方式</th>
												<th class="table-date am-hide-sm-only">下单时间</th>
											</tr>
											</thead>

											<tbody id="ordcont">

											<?php if ($data): ?>
												<tr>
													<td><?php echo $data['orderid'] ?></td>
													<td>
														<div class="am-btn-toolbar">
															<div class="am-btn-group am-btn-group-xs">
																<button onclick="orderInfo('<?php echo $data['orderid'] ?>')" class="am-btn am-btn-default am-btn-xs am-text-secondary">
																	<span class="am-icon-eye"></span>订单详情
																</button>
															</div>
														</div>
													</td>
													<?php
													$orderStatus = [
														1 => "<span class=\"am-badge am-badge-warning am-radius\">待处理</span>",
														2 => " <span class=\"am-badge am-badge-primary am-radius\">已处理</span>",
														3 => " <span class=\"am-badge am-badge-success am-radius\">已完成</span>",
														4 => " <span class=\"am-badge am-badge-danger am-radius\">处理失败</span>",
														5 => " <span class=\"am-badge am-badge-danger am-radius\">发卡失败</span>",
													];
													?>
													<td><?php echo $orderStatus[$data['status']] ?></td>
													<td><?php echo $oname ?></td>
													<td>
														<?php if ($data['otype'] == 0){											
															echo '<span class="am-badge am-badge-success am-radius">自动发卡</span>';
														}else if ($data['otype'] == 2){																		
															echo '<span class="am-badge am-badge-primary am-radius">下载资源</span>';
														}else{																		
															echo '<span class="am-badge am-badge-warning am-radius">手工订单</span>';
														}
														?>
													</td>
													<td><?php echo $data['onum'] ?></td>
													<td><?php echo $data['omoney'] ?></td>
													<td><?php echo $data['cmoney'] ?></td>
													<td><?php echo $data['account'] ?></td>
													<td>
														<span class="am-badge am-badge-success am-radius"><?php echo $paytype ?></span>
													</td>
													<td class="am-hide-sm-only"><?php echo date('Y-m-d H:i', $data['ctime']) ?></td>
												</tr>

											<?php endif; ?>
											</tbody>


										</table>

										<div class="am-cf">

											<div class="am-fr">

											</div>
										</div>
										<hr>


									</div>

								</div>
							</div>
							<div class="tpl-alert"></div>
						</div>


                <!-- Nav tabs card end-->
            </div>
        </div>
    </div>
</div>

             <div class="modal fade" id="url-Modal" tabindex="-1" role="dialog">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div id="qrcode">
                                </div>
                                               
                                    <br><span class="" id="basic-addon1"><strong>扫码看进入下单网+长期合作请保存图</strong></span>
                                               
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary btn-mini btn-block" data-dismiss="modal">关闭</button>
                            </div>
                        </div>
                    </div>
                </div>

				
            </div>
            </div>
        </div>
    </div>
    </div>
    <script src="/static/gmpanel/js/jquery-ui.min.js"></script>
    <script src="/static/gmpanel/js/popper.min.js"></script>
    <script src="/static/gmpanel/js/bootstrap.min.js"></script>
    <script src="/static/gmpanel/js/jquery.slimscroll.js"></script>
    <script src="/static/gmpanel/js/modernizr.js"></script>
    <script src="/static/gmpanel/js/css-scrollbars.js"></script>
    <script src="/static/gmpanel/js/custom-prism.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next/17.0.6/i18next.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next-xhr-backend/3.0.0/i18nextXHRBackend.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next-browser-languagedetector/3.0.1/i18nextBrowserLanguageDetector.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>jquery-i18next/1.2.1/jquery-i18next.min.js"></script>
    <script src="/static/gmpanel/js/qrcode.min.js"></script>
    <script src="/static/gmpanel/js/pcoded.min.js"></script>
    <script src="/static/gmpanel/js/menu-hori-fixed.js"></script>
    <script src="/static/gmpanel/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/static/gmpanel/js/script.js"></script>
	
	

 <script>
	var qrcode = new QRCode('qrcode', {
	text: "<?php echo $this->config['siteurl']; ?>",
	width: 268,
	height: 268,
	colorDark : '#000000',
	colorLight : '#ffffff',
	correctLevel : QRCode.CorrectLevel.H
	});
	$("#qrcode > img").css({"margin":"auto"});

	$('#hi-Modal').modal({backdrop: 'static', keyboard: false})
	</script>
       
    <div class="modal fade" id="search-Modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <form class="form-inline" action="../">
                      <div class="searchdialog" style="margin: 2rem; position: relative;width:100% ">
                        <i class="fa fa-search" style="position: absolute; left: 0; top: 0;  display: inline-block; font-size: 28px; color: #504d77;"></i>
                        <input type="text" name="gname" placeholder="Search" style="display: inline-block; line-height: 1.5; border: none; border-bottom: 1px solid #ccc; outline: none; width: 70%; height: 35px; padding-left: 30px;">
                      <button type="submit" class="btn btn-primary float-right">搜索</button>
                    </div>
                    </form>

                </div>
                
            </div>
        </div>
    </div>
    <script src="/static/gmpanel/js/slick.min.js"></script>
	<script>
<?php
$oid=$this->req->get('oid');
if($oid) {
echo"orderInfo('".$oid."')";
}
?>
</script>
</main> 

  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>
