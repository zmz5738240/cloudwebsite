<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>个人资料—<?php echo $this->config['sitename']; ?></title>
    <meta name="description" content="<?php echo $this->config['sitename']; ?>">
    <meta name="keywords" content="<?php echo $this->config['sitename']; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="/static/default/favico.ico" />
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<!--[if (gte IE 9)|!(IE)]><!--><script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script><!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>modernizr/2.8.3/modernizr.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.ie8polyfill.min.js"></script>
    <![endif]-->
	<script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
    <script src="/static/js/pajax.js"></script>
</head>

<body  id="bg" data-type="user_sett">
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
     <script>
        $(document.body).attr('data-type','user_sett');
    </script>
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
    <style>
	.sy-form{
				background-color: #fff;				
		}
  .am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default .am-footer-miscs{
		color: #fff;
	}
    </style>
<header class="am-topbar am-topbar-inverse">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=<?php echo $this->config['qq']?>&uin=&site=qq&menu=yes" target="_blank" pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout"  pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>

  </div>
</div>
</header>

<div class="tpl-page-container tpl-page-header-fixed">

<div class="am-container tpl-content-wrapper">
       
        <div class="tpl-portlet-components">
            <div class="portlet-title">
                <div class="caption font-green bold">
                    <span class="am-icon-code"></span> 个人设置
                </div>
            </div>
            <div class="tpl-block ">

                <div class="am-g tpl-amazeui-form">

     									<?php if($lists):?>
                                                 
                    <div class="am-u-sm-12 am-u-md-9">
                        <form class="am-form am-form-horizontal">
                            <div class="am-form-group">
                                <label for="user-name" class="am-u-sm-3 am-form-label">用户名</label>
                                <div class="am-u-sm-9">
                                    <input type="text" id="user-name" value="<?php echo $lists['uname']?>" disabled >
                                </div>
                            </div>
                            
                            <div class="am-form-group">
                                <label for="user-email" class="am-u-sm-3 am-form-label">累计消费</label>
                                <div class="am-u-sm-9">
                                    <input type="email" id="user-email" value="<?php echo $lists['allmoney']?>" disabled>
                                </div>
                            </div>

                            <div class="am-form-group">
                                <label for="user-phone" class="am-u-sm-3 am-form-label">邮箱</label>
                                <div class="am-u-sm-9">
                                    <input type="tel" id="user-phone" value="<?php echo $lists['email']?>" disabled>
                                </div>
                            </div>
                            <div class="am-form-group">
                                <label for="user-phone" class="am-u-sm-3 am-form-label">上次登录时间</label>
                                <div class="am-u-sm-9">
                                    <input type="tel" id="user-phone" value="<?php echo date("Y-m-d H:i:s", $lists['ctime']);?>" disabled>
                                </div>
                            </div>
                            <div class="am-form-group">
                                <label for="user-phone" class="am-u-sm-3 am-form-label">上次登录ip</label>
                                <div class="am-u-sm-9">
                                    <input type="tel" id="user-phone" value="<?php echo $lists['last_ip']?>" disabled>
                                </div>
                            </div>

                          <?php endif;?>
                  
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>


</div>

  <footer data-am-widget="footer"
          class="am-footer am-footer-default"
          data-am-footer="{  }">
      
    
    <div class="am-footer-miscs ">
      <p><?php echo $this->config['copyright']?></p>
      <p><?php echo $this->config['icpcode']?></p>
      <p><?php echo $this->config['tel']?></p>
    </div>
  </footer>

  <div id="am-footer-modal"
       class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
    <div class="am-modal-dialog">
      <div class="am-modal-hd am-modal-footer-hd">
        <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
      </div>
      <div class="am-modal-bd">
		<?php echo $this->config['copyright']?>
		<?php echo $this->config['icpcode']?>
		<?php echo $this->config['tel']?>
	
      </div>
    </div>
  </div>
<?php echo $this->bgrand();?>
<script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
<script src="/static/common/layer/layer.js"></script>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<?php echo $this->config['stacode']?>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>