<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <script src="<?php echo $this->config['cdnpublic']?>jquery/3.2.1/jquery.min.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body >
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
<link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/4.0.0-beta.3/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $this->config['cdnpublic']?>prism/9000.0.1/themes/prism.min.css">
<link rel="stylesheet" type="text/css" href="/static/gmpanel/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="/static/gmpanel/style.css">
<link rel="stylesheet" type="text/css" href="/static/gmpanel/jquery.mCustomScrollbar.css">
<link rel="stylesheet" type="text/css" href="/static/gmpanel/pcoded-horizontal.min.css">	
<link href="/static/gmpanel/gmpanel.css?v4.18" type="text/css" rel="stylesheet">
<style type="text/css">
	.pcoded .pcoded-header{
	    background: <?php echo $this->config['color'];?> !important;
	}
	.text-primary {
	    color: <?php echo $this->config['color'];?> !important;
	}
	.btn-primary {
	    background-color: <?php echo $this->config['color'];?> !important;
	    border-color: <?php echo $this->config['color'];?> !important;
	}
	.btn-primary:hover, .sweet-alert button.confirm:hover, .wizard > .actions a:hover {
	    background-color: <?php echo $this->config['color'];?> !important;
	    border-color: <?php echo $this->config['color'];?> !important;
	}
	.input-group-addon {
	    background-color: <?php echo $this->config['color'];?>;
	    color: #fff;
	}
	#accordion .panel-title a {
	    background: <?php echo $this->config['color'];?> !important;
	}
	#accordion .panel-title a:after,
	#accordion .panel-title a.collapsed:after{
	    background: <?php echo $this->config['color'];if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";}?> !important;
	}
	</style>
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <div id="pcoded" class="pcoded">
        <div class="pcoded-container">
            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="<?php echo $this->config['siteurl']; ?>">
                            <img class="img-fluid" src="<?php echo $this->config['logo']?>" alt="<?php echo $this->config['sitename']?>" />
                        </a>
                        <a class="mobile-options">
                            更多 <i class="fa fa-ellipsis-v"></i>
                        </a>
                    </div>

                    <div class="navbar-container container-fluid">
                        <ul class="nav-right">
                            
                            <li>
                                 <a href="#" data-toggle="modal" data-target="#search-Modal" target="_blank">
                                    <i class="fa fa-search"></i> 搜索宝贝
                                </a>
                            </li>
                            <li>
                                <a href="#"data-toggle="modal" data-target="#url-Modal" target="_blank">
                                    <i class="fa fa-opera"></i> 站点扫码
                                </a>
                            </li>
                            

                            
                            <li>
                                <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank"  pjax="exclude">
                                    <i class="fa fa-commenting"></i> 联系客服
                                </a>
                            </li>
                            

                            
                            <li>
                                <a href="<?php echo $this->config['qqqun']?>" target="_blank">
                                    <i class="fa fa-comments"></i> 加入Q群
                                </a>
                            </li>
                            
                            <li>
                                <a href="/chaka">
                                    <i class="fa fa-search"></i> 订单查询
                                </a>
                            </li>
                            
							
							<?php if($this->session->get('login_name')) { ?>
							<li>
                                    <a href="javascript:;" onclick="repwd()">
                                         <i class="fa fa-user"></i> 修改密码
                                    </a>
                                </li>
								<li>
                                    <a href="/user">
                                         <i class="fa fa-user"></i> 会员中心
                                    </a>
                                </li>
						<?php }else{ ?>		

                                <li>
                                    <a href="/login">
                                         <i class="fa fa-user"></i> 登陆
                                    </a>
                                </li>
                                <li>
                                    <a href="/reg">
                                         <i class="fa fa-cloud-download"></i>注册
                                    </a>
                                </li>
						<?php } ?> 	


                            
                            
                        </ul>

                    </div>
                </div>
            </nav>
	<div class="pcoded-main-container">
    <div class="pcoded-wrapper d-block d-lg-none">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-body">
                        <div class="page-body">
                            
                            <div class="card" style="margin-bottom: 10px;">
                                <div style="margin: 5px 8px 5px 8px;color: #666666;margin-bottom: -13px;">
                                    <p>
									<?php echo $this->config['tips'];
									if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";}
									?>
									</p>
                                </div>
                            </div>
                        </div>
                        <div class="page-body" id="mobile_div">
											<!---- mobile--->
											
												
												
											<?php foreach($class as $vals):?>
												  <div class="card" style="margin-bottom: 10px;">
												   <div class="card-block">
													<div class="form-horizontal">
													 <div class="row">
													 
													  <h4 class="sub-title" style="margin-bottom: 0px; margin-top: -6px; width: 100%;"><i class="fa fa-shopping-cart"></i><?php echo $vals['title'];?></h4>	
													  <?php foreach ($lists as $val): ?>
													   <?php if ($vals['id']==$val['cid']){ ?>
													   <a href="<?php echo  "http://".$this->url_host.$producturl.$val['id']; ?>">
													  <div class="baoliao_content">
													  
													   <div class="b_img" style="float: left; width: 20%;">
                                                            <img src="<?php echo $val['image']?>" style="height:70px" alt="avatar" class="lazy img-circle img-thumbnail img-thumbnail-avatar" width="70">
                                                        </div>
                                                        <div class="bl_left" style="display: inline-block;">
                                                            <div class="bl_title"><strong><p class="text-left"><?php echo $val['gname'] ?></p></strong>
                                                            </div>
                                                            <span class="label label-primary">
                                                                <?php if($val['type']==0){
																		echo '激活码';																	
																}else if($val['type']==1){
																		echo '代充';
																}else{	
																		echo '下载';
																}?>                                                            </span>
                                                                                                                        <span class="label label-success">
                                                                库存&nbsp;<?php echo $val['kuc'] ?>                                                          </span>
                                                            <span class="label label-danger"> <b><i class="fa fa-cny"></i>                                                                                                                                                <?php echo $val['price'] ?>                                                                                                                                  </b></span>
                                                            <span class="text-primary product-price f-right" style="margin-top: 1px;">
                                                            </span>
                                                        </div>													   
													  </div>
													  </a>
													  
													  
													  
												   <?php }?>
												   <?php endforeach;?> 
													 </div>
													</div>
												   </div>
												  </div>
											<?php endforeach;?>
				   
											<!---- mobile--->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                
            </div>
        </div>
        
       
    <div class="modal fade" id="search-Modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <form class="form-inline" action="../">
                      <div class="searchdialog" style="margin: 2rem; position: relative;width:100% ">
                        <i class="fa fa-search" style="position: absolute; left: 0; top: 0;  display: inline-block; font-size: 28px; color: #504d77;"></i>
                        <input type="text" name="gname" placeholder="Search" style="display: inline-block; line-height: 1.5; border: none; border-bottom: 1px solid #ccc; outline: none; width: 70%; height: 35px; padding-left: 30px;">
                      <button type="submit" class="btn btn-primary float-right">搜索</button>
                    </div>
                    </form>

                </div>
                
            </div>
        </div>
    </div>
    </div>
    <script src="/static/gmpanel/js/jquery-ui.min.js"></script>
    <script src="/static/gmpanel/js/popper.min.js"></script>
    <script src="/static/gmpanel/js/bootstrap.min.js"></script>
    <script src="/static/gmpanel/js/jquery.slimscroll.js"></script>
    <script src="/static/gmpanel/js/modernizr.js"></script>
    <script src="/static/gmpanel/js/css-scrollbars.js"></script>
    <script src="/static/gmpanel/js/custom-prism.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next/17.0.6/i18next.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next-xhr-backend/3.0.0/i18nextXHRBackend.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>i18next-browser-languagedetector/3.0.1/i18nextBrowserLanguageDetector.min.js"></script>
    <script src="<?php echo $this->config['cdnpublic']?>jquery-i18next/1.2.1/jquery-i18next.min.js"></script>
    <script src="/static/gmpanel/js/qrcode.min.js"></script>
    <script src="/static/gmpanel/js/pcoded.min.js"></script>
    <script src="/static/gmpanel/js/menu-hori-fixed.js"></script>
    <script src="/static/gmpanel/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/static/gmpanel/js/script.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
	<script src="/static/default/js/app.js"></script>
    
<script>
var qrcode = new QRCode('qrcode', {
text: "<?php echo $this->config['siteurl']; ?>",
width: 268,
height: 268,
colorDark : '#000000',
colorLight : '#ffffff',
correctLevel : QRCode.CorrectLevel.H
});
$("#qrcode > img").css({"margin":"auto"});

</script>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>