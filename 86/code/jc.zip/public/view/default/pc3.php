<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $this->config['sitename']?></title>
    <meta name="description" content="<?php echo $this->config['description']?>">
    <meta name="keywords" content="<?php echo $this->config['keyword']?>">
	<script src="<?php echo $this->config['cdnpublic']?>jquery/2.0.3/jquery.min.js"></script>
	<script src="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/js/amazeui.min.js"></script>	
	<script src="<?php echo $this->config['cdnpublic']?>layer/2.3/layer.js"></script>
    <script src="/static/js/pajax.js"></script>
</head>
<body id="bg">    
<script type="text/javascript">
    $(document).pjax('a[pjax!="exclude"]', '#site-main', {fragment:'#site-main', timeout:8000});
</script>   
<main id="site-main">
	<link rel="stylesheet" href="<?php echo $this->config['cdnpublic']?>amazeui/2.7.2/css/amazeui.min.css">
	<link href="<?php echo $this->config['cdnpublic']?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/static/default/assets/css/admin.css">
    <link rel="stylesheet" href="/static/default/assets/css/app.css">
    <style type="text/css"> 
  	.am-topbar-inverse{
		background-color:<?php echo $this->config['color'];?>;
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default{
		background-color:<?php echo $this->config['color'];?>;
	}
	.good_border{
		border:5px solid <?php echo $this->config['color'];?>;
	}
	.good_border:hover{
	    border-color: rgba(234, 18, 18, 0.73);
	}
	
	
	
	.am-panel-primary{
		border-color:<?php echo $this->config['color'];?>;
	}
	.am-footer-default .am-footer-miscs{
		color: #fff;
	}
        .am-container{
          max-width: 1200px;
        }
    
        /* 色调设置 */
       .good-trade{
             background-color: #fff;
        }
		.sy-form{
				background-color: #fff;				
		}
		.floatfl{
			    text-align: center!important;
			float:left!important;
		}
    </style>
  <header class="am-topbar am-topbar-inverse am-header-fixed">
<div class="am-container">
<h1 class="am-topbar-btn am-fl am-btn am-btn-sm am-btn-success am-show-sm-only">
    <a href="/"><i class="am-header-icon am-icon-home"></i></a>
  </h1>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav ">
      <li><a href="/"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
      <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $this->config['qq']?>&site=qq&menu=yes" target="_blank" pjax="exclude"><i class="am-icon-qq"></i>客服</a></li>
      	  <?php if($this->session->get('login_name')) { ?>		  
				  <li><a href="/user"><span class="am-icon-users"></span>会员中心</a></li>
				  <li><a href="/user/sett"><span class="am-icon-cog"></span>个人资料</a></li>	  	  
				  <li><a href="javascript:;" onclick="repwd()"><span class="am-icon-lock"></span>修改密码</a></li>
				  <li><a href="/login/logout" pjax="exclude"><span class="am-icon-sign-out"></span>退出</a></li>
           <?php }else{ ?>		   
			  <li><a href="/login"><span class="am-icon-sign-in"></span>登录</a></li>	
			  <li><a href="/reg"><span class="am-icon-sign-out"></span>注册</a></li> 
              <?php } ?> 
    </ul>	
    <form action="//<?php echo $this->url_host;?>" method="get" class="am-topbar-form am-topbar-left am-form-inline sy-form" role="search">
      <div class="am-form-group">
        <input type="text" name="gname" class="am-form-field am-input-sm" placeholder="搜索">
      </div>
    </form>

    <div class="am-topbar-right">
			<ul class="am-nav am-nav-pills am-topbar-nav">
            <li><a href="/chaka"><span class="am-icon-search"></span>订单查询</a></li>
            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
          </ul>     
    </div>
  </div>
</div>
</header>
<div class="am-topbar"></div>
<div class="am-container" style="padding:2px">    
        <div class="am-panel am-panel-default" style="margin:5px 0 5px 0;border-radius: 0px">
      <div class="am-panel-bd "><?php echo $this->config['tips'];if($this->config['cp_jt'] == 0){$producturl="/product?id=";}else{$producturl="/product/";} ?></div>
    </div>
   <div class="goods">
					 <div class="am-show-landscape">
                              <ul class="am-avg-sm-2 am-avg-md-3 am-avg-lg-4 am-thumbnails">
                                  
                               <?php foreach ($lists as $key => $val): ?>
                                <li ><a href="<?php echo  "//".$this->url_host.$producturl.$val['id']; ?>" >
                                    <div style="background-color: #fff;" class="index_good_body good_border">                      
                                    <img src="<?php echo $val['image'] ?>" style="width:100%;height:280px"/>
                                    <div class="pr-info" style="padding:5px">
                                      <span class="price">¥<?php echo $val['price'] ?></span>
                                                                            <span class="pr-xl am-badge am-badge-danger" style="color:#fff">库存<?php echo $val['kuc'] ?>张</span>
                      					<input id="cp<?php echo $val['id']?>" data-pwd<?php echo $val['pwd']?> type="hidden">                             
                                      <div class="index-goodname-xq" style="height:45px;color:#333"><p title="<?php echo $val['gname'] ?>"><?php echo $val['gname'] ?></p></div>
                                      </div>
                                    </div>
                                </a>
                                </li>
               				 <?php endforeach; ?>                                 
                       		</ul>
                        </div>
     
						  <?php echo $lists ? $pagelist : '' ?>
    </div>
    </div>
  <footer data-am-widget="footer"
          class="am-footer am-footer-default"
          data-am-footer="{  }">
    <div class="am-footer-switch">
        友情链接：
	<?php 
	$link = $this->links;
	if($link):?>
	<?php foreach($link as $key=>
	$val):?>
	<span class="am-footer-divider"> | </span>
	<a class="am-footer-desktop" href="<?php echo $val['url']?>" target="_blank">
	<?php echo $val['title']?>
	</a>
	<?php endforeach;?>
	<?php endif;?>
    </div>
    
    <div class="am-footer-miscs ">
      <p><?php echo $this->config['copyright']?></p>
      <p><?php echo $this->config['icpcode']?'  <a href="https://beian.miit.gov.cn" target="_blank" rel="noreferrer nofollow">'.$this->config['icpcode'].'</a>  ':''         
;?></p>
      <p><?php echo $this->config['tel']?></p>
    </div>
  </footer>

  <div id="am-footer-modal"
       class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
    <div class="am-modal-dialog">
      <div class="am-modal-hd am-modal-footer-hd">
        <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
      </div>
      <div class="am-modal-bd">
		<?php echo $this->config['copyright']?>
		<?php echo $this->config['icpcode']?'  <a href="https://beian.miit.gov.cn" target="_blank" rel="noreferrer nofollow">'.$this->config['icpcode'].'</a>  ':''         
;?>
		<?php echo $this->config['tel']?>
	
      </div>
    </div>
  </div>
</main> 
<?php echo $this->bgrand();?>
<script src="/static/default/assets/js/app.js"></script>
<script src="/static/default/js/app.js"></script>
<script src="<?php echo $this->config['cdnpublic']?>screenfull.js/5.0.0/screenfull.min.js"></script>
<?php echo $this->config['stacode']?>
</main> 
  <?php if ($this->config['mp3_state']=='1'){
	echo $this->config['mp3list'];}
	?>
</body>
</html>    