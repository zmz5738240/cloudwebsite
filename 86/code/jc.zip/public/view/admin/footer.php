
    </div>
    </div>
    </div>
    </div>
    </div>
    <div id="footer">
        &copy;&nbsp;
        <?php echo date('Y')."&nbsp;". $this->
            config['sitename']?>&nbsp
    </div>
    <div class="modal" id="waModal" role="dialog" aria-labelledby="waModalLable">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">
                            &times;
                        </span>
                    </button>
                    <h4 class="modal-title">
                        Modal title
                    </h4>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    </body>
    
    </html>