<?php require_once 'header.php' ?>
    <style>
        .form-ajax>.form-group>.col-md-6{color:#6B6D6E;font-size:0.9em;line-height:
        30px}.form-ajax>.form-group>.col-md-2{color:#6B6D6E;}
    </style>
    <script charset="utf-8" src="/view/editor/kindeditor-min.js">
    </script>
    <script charset="utf-8" src="/view/editor/lang/zh_CN.js">
    </script>
    <script>
        var editor;
        KindEditor.ready(function(K) {
            editor = K.create('textarea[name="tips"]', {
                allowFileManager: false,
            });
        });
    </script>
    <h3>
        <span class="current">
            系统设置
        </span>
        &nbsp;/&nbsp;
        <span>
            注册设置
        </span>
        &nbsp;/&nbsp;
        <span>
            邮件服务器
        </span>
        &nbsp;/&nbsp;
        <span>
            公告设置
        </span>
        &nbsp;/&nbsp;
        <span>
            库存告警策略
        </span>
        &nbsp;/&nbsp;
        <span>
            音乐设置
        </span>
    </h3>
    <br>
    <div class="set set0">
    <script>
        var editor;
        KindEditor.ready(function(K) {          
		var editor = K.editor({
         allowFileManager : true
        });
        K('#upload').click(function() {
         editor.loadPlugin('image', function() {
          editor.plugin.imageDialog({
           imageUrl : K('#image').val(),
           clickFn : function(url, title, width, height, border, align) {
            K('#image').val(url);
            K('#keUrl').val(url);
            K('#up1').attr('src',url);
            editor.hideDialog();
           }
          });
         });
        });
        
        K('#upload2').click(function() {
         editor.loadPlugin('image', function() {
          editor.plugin.imageDialog({
           imageUrl : K('#upload2').val(),
           clickFn : function(url, title, width, height, border, align) {
            K('#upload2').val(url);
            K('#keUrl').val(url);
            K('#up2').attr('src',url);
			keUrl
            editor.hideDialog();
           }
          });
         });
        }); 
          
        });
    </script>
      
<form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
        method="post" autocomplete="off">
            <div class="form-group">
                <label for="sitename" class="col-md-2 control-label">
                    站点名称：
                </label>
                <div class="col-md-6">
                    <input type="text" name="sitename" id="sitename" class="form-control"
                    value="<?php echo $this->config['sitename']?>">
                </div>
                <span class="col-md-4">
                    网站title
                </span>
            </div>
    	<div class="form-group">
            <label for="bodyimage" class="col-md-2 control-label">
                自定义背景图：
            </label>
            <div class="col-md-4">
             <input type="text" name="bodyimage" class="form-control" id="upload2" value="<?php echo $this->config['bodyimage']?>" >
             <?php if (mb_strlen($this->config['bodyimage'])>5) { ?>
              <img src="<?php if (strpos($this->config['bodyimage'], "//") != false) { echo $this->config['bodyimage']; }else{
				echo  "../../../".$this->config['bodyimage'];
			  }?>" style="height:50px;width:auto;" class="img-rounded" id="up2">
			  <?php } ?>
            </div>            
                <span class="col-md-4">
                    点击输入框修改
                </span>
        </div>
		
		
            <div class="form-group">
                <label for="sg_kuc" class="col-md-2 control-label">
                    手工商品减库存：
                </label>
                <div class="col-md-4">
                    <select name="sg_kuc" class="form-control">
                        <option value="1" <?php echo $this->config['sg_kuc']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['sg_kuc']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
            </div>
		
		
        <div class="form-group">
            <label for="cdnpublic" class="col-md-2 control-label">
                公共静态资源CDN：
            </label>
            <div class="col-md-4">
                <select name="cdnpublic" class="form-control">
                    <option value="//cdn.staticfile.org/" <?php echo $this->config['cdnpublic']=='//cdn.staticfile.org/' ? ' selected' : ''?>>七牛云CDN
                    </option>
                    <option value="//lib.baomitu.com/" <?php echo $this->config['cdnpublic']=='//lib.baomitu.com/' ? ' selected' : ''?>>360CDN
                    </option>
                    <option value="//cdn.bootcdn.net/ajax/libs/" <?php echo $this->config['cdnpublic']=='//cdn.bootcdn.net/ajax/libs/' ? ' selected' : ''?>>BootCDN
                    </option>
                    <option value="//s1.pstatp.com/cdn/expire-1-M/" <?php echo $this->config['cdnpublic']=='//s1.pstatp.com/cdn/expire-1-M/' ? ' selected' : ''?>>今日头条CDN
                    </option>
                </select>
            </div>
        </div>
          <div class="form-group">
            <label for="bodyimage" class="col-md-2 control-label">
                网站logo：
            </label>
            <div class="col-md-6" id="upload">
             <input type="text"  name="logo"  id="image" value="<?php echo $this->config['logo']?>" >
              <img src="<?php if (strpos($this->config['logo'], "//") != false) { echo $this->config['logo']; }else{
				echo  "../../../".$this->config['logo'];
			  }?>" style="height:50px;width:auto;background-color: rgba(64, 158, 255, 0.36);" class="img-rounded" id="up1">
            </div>            
                <span class="col-md-4">
                    点击输入框修改
                </span>
        </div>
          
            <div class="form-group">
                <label for="siteurl" class="col-md-2 control-label">
                    站点网址：
                </label>
                <div class="col-md-6">
                    <input type="text" name="siteurl" id="siteurl" class="form-control" value="<?php echo $this->config['siteurl']?>">
                </div>
            </div>

            <div class="form-group">
                <label for="keyword" class="col-md-2 control-label">
                    网站关键字：
                </label>
                <div class="col-md-6">
                    <input type="text" name="keyword" id="keyword" class="form-control" value="<?php echo $this->config['keyword']?>">
                </div>
            </div>
            <div class="form-group">
                <label for="description" class="col-md-2 control-label">
                    网站介绍：
                </label>
                <div class="col-md-6">
                    <textarea name="description" id="description" class="form-control" rows="5"><?php echo $this->config['description']?></textarea>
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="ctime" class="col-md-2 control-label">
                    建站时间：
                </label>
                <div class="col-md-6">
                    <input type="date" name="ctime" id="ctime" class="form-control" value="<?php echo $this->config['ctime']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="email" class="col-md-2 control-label">
                    客服邮箱：
                </label>
                <div class="col-md-6">
                    <input type="text" name="email" id="email" class="form-control" value="<?php echo $this->config['email']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="tel" class="col-md-2 control-label">
                    客服电话：
                </label>
                <div class="col-md-6">
                    <input type="text" name="tel" id="tel" class="form-control" value="<?php echo $this->config['tel']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="qq" class="col-md-2 control-label">
                    客服QQ：
                </label>
                <div class="col-md-6">
                    <input type="text" name="qq" id="qq" class="form-control" value="<?php echo $this->config['qq']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
			
			
            <div class="form-group">
                <label for="qq" class="col-md-2 control-label">
                    gmpanel 群QQ：
                </label>
                <div class="col-md-6">
                    <input type="text" name="qqqun" id="qqqun" class="form-control" value="<?php echo $this->config['qqqun']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
			
			
            <div class="form-group">
                <label for="address" class="col-md-2 control-label">
                    公司地址：
                </label>
                <div class="col-md-6">
                    <input type="text" name="address" id="address" class="form-control" value="<?php echo $this->config['address']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="icpcode" class="col-md-2 control-label">
                    ICP备案号：
                </label>
                <div class="col-md-6">
                    <input type="text" name="icpcode" id="icpcode" class="form-control" value="<?php echo $this->config['icpcode']?>">
                </div>
                <span class="col-md-4">
                </span>
            </div>
			
            <div class="form-group">
                <label for="copyright" class="col-md-2 control-label">
                    底部版权：
                </label>
                <div class="col-md-6">
                    <textarea name="copyright" id="copyright" class="form-control" rows="5">
                        <?php echo $this->config['copyright']?>
                    </textarea>
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                    统计代码：
                </label>
                <div class="col-md-6">
                    <textarea name="stacode" id="stacode" class="form-control" rows="5">
                        <?php echo $this->config['stacode']?>
                    </textarea>
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="xieyi" class="col-md-2 control-label">
                    注册协议：
                </label>
                <div class="col-md-6">
                    <textarea name="xieyi" id="stacode" class="form-control" rows="5">
                        <?php echo $this->config['xieyi']?>
                    </textarea>
                </div>
                <span class="col-md-4">
                </span>
            </div>
            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-4">
                </span>
            </div>
        </form>
    </div>

    <div class="set set1 hide">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
              method="post" autocomplete="off">
            <div class="form-group">
                <label for="sw_reg" class="col-md-2 control-label">
                    注册开关：
                </label>
                <div class="col-md-4">
                    <select name="sw_reg" class="form-control">
                        <option value="1" <?php echo $this->config['sw_reg']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['sw_reg']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="gw_reg" class="col-md-2 control-label">
                    登录购买：
                </label>
                <div class="col-md-4">
                    <select name="gw_reg" class="form-control">
                        <option value="1" <?php echo $this->config['gw_reg']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['gw_reg']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="regle" class="col-md-2 control-label">
                    默认用户等级：
                </label>
                <div class="col-md-4">
                    <select name="regle" class="form-control">
                        <?php if ($ulevel): ?>
                            <?php foreach ($ulevel as $key =>
                                           $val): ?>
                                <option value="<?php echo $val['id'] ?>" <?php echo $val['id'] == $this->config['regle'] ? ' selected' : '' ?>>
                                    <?php echo $val['title'] ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>


            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>
	
    <div class="set set2 hide">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
        method="post" autocomplete="off">
            <div class="form-group">
                <label for="smtp_server" class="col-md-2 control-label">
                    邮件服务器：
                </label>
                <div class="col-md-4">
                    <input type="text" name="smtp_server" id="smtp_server" class="form-control"
                    value="<?php echo $this->config['smtp_server']?>">
                </div>
                <span class="col-md-6">
                    以smtp开头
                </span>
            </div>
            <div class="form-group">
                <label for="smtp_email" class="col-md-2 control-label">
                    邮箱账号：
                </label>
                <div class="col-md-4">
                    <input type="text" name="smtp_email" id="smtp_email" class="form-control"
                    value="<?php echo $this->config['smtp_email']?>">
                </div>
                <span class="col-md-6">
                </span>
            </div>
            <div class="form-group">
                <label for="smtp_pwd" class="col-md-2 control-label">
                    邮箱密码：
                </label>
                <div class="col-md-4">
                    <input type="password" name="smtp_pwd" id="smtp_pwd" class="form-control"
                    value="<?php echo $this->config['smtp_pwd']?>">
                </div>
                <span class="col-md-6">
                </span>
            </div>
            <div class="form-group">
                <label for="email_state" class="col-md-2 control-label">
                    邮件开关：
                </label>
                <div class="col-md-4">
                    <select name="email_state" class="form-control">
                        <option value="1" <?php echo $this->config['email_state']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['email_state']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>

    <div class="set set3 hide">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
              method="post" autocomplete="off">

            <div class="form-group">
                <label for="tips" class="col-md-2 control-label">
                    公告内容：
                </label>
                <div class="col-md-4">
                    <textarea name="tips" style="width:100%;height:300px;visibility:hidden;">
                    <?php echo $this->config['tips']?>
                </textarea>
                </div>
                <span class="col-md-6">
                </span>
            </div>

            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>

    <div class="set set4 hide">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
              method="post" autocomplete="off">

            <div class="form-group">
                <label for="ismail_num" class="col-md-2 control-label">
                    告警阈值：
                </label>
                <div class="col-md-4">
                    <input type="text" name="ismail_num" id="ismail_num" class="form-control"
                           value="<?php echo $this->config['ismail_num']?>">
                </div>
                <span class="col-md-6">
                    库存低于多少告警
                </span>
            </div>

            <div class="form-group">
                <label for="serive_token" class="col-md-2 control-label">
                    Token：
                </label>
                <div class="col-md-4">
                    <input type="text" name="serive_token" id="ismail_num" class="form-control"
                           value="<?php echo $this->config['serive_token']?>">
                </div>
                <span class="col-md-6">
                    用于订单清理或库存告警定时任务通讯密钥
                </span>
            </div>

            <div class="form-group">
                <label for="ismail_kuc" class="col-md-2 control-label">
                    库存告警开关：
                </label>
                <div class="col-md-4">
                    <select name="ismail_kuc" class="form-control">
                        <option value="1" <?php echo $this->config['ismail_kuc']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['ismail_kuc']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
                <span class="col-md-6">
                    定时任务 访问url  一小时或者十分钟 自己感觉<?php echo $this->urlbase. $this->url_host . '/clean?token='.$this->config['serive_token'];?>
                </span>
                
            </div>

            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>

    <div class="set set5 hide">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>set/save"
              method="post" autocomplete="off">

            <div class="form-group">
                <label for="mp3list" class="col-md-2 control-label">
                    音乐列表：
                </label>
                <div class="col-md-6">
				  <textarea name="mp3list" id="mp3list" class="form-control" rows="5">
                        <?php echo $this->config['mp3list']?>
                    </textarea>
                </div>
                <span class="col-md-4">
                    <a href="//music.lailiyun.com" target="_blank">音乐代码获取</a>
                </span>
            </div>

            <div class="form-group">
                <label for="mp3_state" class="col-md-2 control-label">
                    音乐开关：
                </label>
                <div class="col-md-4">
                    <select name="mp3_state" class="form-control">
                        <option value="1" <?php echo $this->config['mp3_state']=='1' ? ' selected' : ''?>>已开启
                        </option>
                        <option value="0" <?php echo $this->config['mp3_state']=='0' ? ' selected' : ''?>>已关闭
                        </option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>
    <?php require_once 'footer.php' ?>