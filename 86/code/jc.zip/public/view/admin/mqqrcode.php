<?php require_once 'header.php' ?>
<link rel="stylesheet" type="text/css" href="https://www.layuicdn.com/layui-v2.4.5/css/layui.css?v=201811010202">

<style>
    .layui-table-cell {
        height: auto;
    }
    .layui-table img {
        max-width: 200px;
    }
</style>

<div class="layui-form layui-form-pane" action="">
<div class="layui-form-item">

    <div class="layui-inline">
        <label class="layui-form-label">支付方式</label>
        <div class="layui-input-inline">
            <select id="type" lay-verify="required" lay-filter="type">
                <option value="666">不限制</option>
                <option value="3">微信</option>
                <option value="2">聚合码</option>
                <option value="1">支付宝</option>

            </select>
        </div>
    </div>



</div>
</div>


<table id="demo" lay-filter="test"></table>
<script src="https://www.layuicdn.com/layui-v2.4.5/layui.js?v=201811010202"></script>
<script type="text/html" id="barDemo">
    <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
</script>


<script>
    function formatDate(now) {
        now = new Date(now*1000);
        return now.getFullYear()
            + "-" + (now.getMonth()>8?(now.getMonth()+1):"0"+(now.getMonth()+1))
            + "-" + (now.getDate()>9?now.getDate():"0"+now.getDate())
            + " " + (now.getHours()>9?now.getHours():"0"+now.getHours())
            + ":" + (now.getMinutes()>9?now.getMinutes():"0"+now.getMinutes())
            + ":" + (now.getSeconds()>9?now.getSeconds():"0"+now.getSeconds());

    }
    var myTable,table,form;
    layui.use(['form','table','laydate'], function(){
        table = layui.table;
        form = layui.form;

        //第一个实例
        myTable = table.render({
            elem: '#demo'
            ,height: 'full-130'
            ,url: 'getPayQrcodes'
            ,where: {
                type:$("#type").val(),
            }
            ,cols: [[ //表头
                {field: 'state', title: '二维码',templet: function(d){
				var emw ="<?php echo $this->config['siteurl'];?>/qrcode?size=100&text=";
                        return '<img src="'+emw+encodeURIComponent(d.pay_url)+'"/>';
                    }
                },
                {field: 'type', title: '类型',templet: function(d){
				
						if (d.type=="2"){
                            return '聚合码';
                        }else if (d.type=="3"){
                            return '微信';
                        }else if (d.type=="1"){
                            return '支付宝';
                        }
                        return '<img src="'+emw+d.pay_url+'"/>';
                    }
                },
                {field: 'price', title: '金额'},
                {title:"操作", width: 70, align:'center', toolbar: '#barDemo'}

            ]]
            ,page:true
        });

        form.on('select(type)', function(data){
            myTable.reload({
                where: {
                    type:$("#type").val()
                }
            });

        });


        //监听行工具事件
        table.on('tool(test)', function(obj){ //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
            var data = obj.data //获得当前行数据
                ,layEvent = obj.event; //获得 lay-event 对应的值
            if(layEvent === 'del'){
                layer.confirm('要删除该二维码么？', function(index){

                    layer.close(index);
                    //向服务端发送删除指令
                    $.post("delPayQrcode","id="+data.id,function (data) {
                        if (data.code==1){
                            obj.del(); //删除对应行（tr）的DOM结构
                        }

                        layer.msg(data.msg);
                    });

                    console.log(data.id);
                });
            }
        });




        form.render();

    });


</script>
    <?php require_once 'footer.php' ?>	