<?php require_once 'header.php' ?>

    <div class="set set0">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>pc/save"
              method="post" autocomplete="off">
        	
            <div class="form-group">
               <label for="pcindex" class="col-md-2 control-label">
                    首页模式：
              </label>
			
			  <div class="col-md-9">
							<div class="col-sm-6 col-md-3">
								<div class="thumbnail">
									<img src="/static/admin/muban/pc1.jpg" 
									alt="列表模式" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>列表模式</h3>
										
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="1" <?php if ($this->config['pcindex'] == 1): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								</div>
							</div>
							<div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/pc2.jpg" 
									 alt="格子模式" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>格子模式</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="2" <?php if ($this->config['pcindex'] == 2): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
						
							
							<div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/pc3.jpg" 
									 alt="图片模式" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>图片模式</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="3" <?php if ($this->config['pcindex'] == 3): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							  <div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/pc4.jpg" 
									 alt="列表格子" style="height: auto;">
									<div class="caption">
										<h3>列表格子</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="4" <?php if ($this->config['pcindex'] == 4): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							
							
							<div class="col-sm-6 col-md-3">
							   <div class="thumbnail">
									<img src="/static/admin/muban/pc5.jpg" 
									 alt="仿gmpanel" style="height: auto;">
									<div class="caption">
										<h3>仿gmpanel</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="5" <?php if ($this->config['pcindex'] == 5): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							
							<div class="col-sm-6 col-md-3">
							   <div class="thumbnail">
									<img src="/static/admin/muban/pc0.jpg" 
									 alt="分类模式A" style="height: auto;">
									<div class="caption">
										<h3>分类模式A</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="0" <?php if ($this->config['pcindex'] == 0): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							
							<div class="col-sm-6 col-md-3">
							   <div class="thumbnail">
									<img src="/static/admin/muban/pc6.jpg" 
									 alt="分类模式B" style="height: auto;">
									<div class="caption">
										<h3>分类模式B</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="pcindex" id="pcindex" value="6" <?php if ($this->config['pcindex'] == 6): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
				</div>  
      </div>
		
      
        
        <div class="form-group">
            <label for="background" class="col-md-2 control-label">
                随机背景图：
            </label>
            <div class="col-md-4">
                <select name="background" class="form-control">
                    <option value="0" <?php echo $this->config['background']=='0' ? ' selected' : ''?>>关闭
                    </option>
                    <option value="1" <?php echo $this->config['background']=='1' ? ' selected' : ''?>>自定义背景
                    </option>
                    <option value="99" <?php echo $this->config['background']=='99' ? ' selected' : ''?>>随机最新
                    </option>
                    <option value="36" <?php echo $this->config['background']=='36' ? ' selected' : ''?>>4K专区
                    </option>
                    <option value="6" <?php echo $this->config['background']=='6' ? ' selected' : ''?>>美女模特
                    </option>
                    <option value="30" <?php echo $this->config['background']=='30' ? ' selected' : ''?>>爱情美图
                    </option>
                    <option value="9" <?php echo $this->config['background']=='9' ? ' selected' : ''?>>风景大片
                    </option>
                    <option value="15" <?php echo $this->config['background']=='15' ? ' selected' : ''?>>小清新
                    </option>
                    <option value="26" <?php echo $this->config['background']=='26' ? ' selected' : ''?>>动漫卡通
                    </option>
                    <option value="11" <?php echo $this->config['background']=='11' ? ' selected' : ''?>>明星风尚
                    </option>
                    <option value="14" <?php echo $this->config['background']=='14' ? ' selected' : ''?>>萌宠动物
                    </option>
                    <option value="5" <?php echo $this->config['background']=='5' ? ' selected' : ''?>>游戏壁纸
                    </option>
                    <option value="10" <?php echo $this->config['background']=='10' ? ' selected' : ''?>>汽车天下
                    </option>
                    <option value="10" <?php echo $this->config['background']=='10' ? ' selected' : ''?>>炫酷时尚
                    </option>
                    <option value="7" <?php echo $this->config['background']=='7' ? ' selected' : ''?>>影视剧照
                    </option>
                    <option value="29" <?php echo $this->config['background']=='29' ? ' selected' : ''?>>月历壁纸
                    </option>
                    <option value="22" <?php echo $this->config['background']=='22' ? ' selected' : ''?>>军事天地
                    </option>
                    <option value="12" <?php echo $this->config['background']=='12' ? ' selected' : ''?>>劲爆体育
                    </option>
                    <option value="18" <?php echo $this->config['background']=='18' ? ' selected' : ''?>>BABY秀
                    </option>
                    <option value="35" <?php echo $this->config['background']=='35' ? ' selected' : ''?>>文字控
                    </option>
                </select>
            </div>
        </div>
            
            <div class="form-group">
                <label for="cp_jt" class="col-md-2 control-label">
                    产品url：
                </label>
                <div class="col-md-4">
                    <select name="cp_jt" class="form-control">
                        <option value="1" <?php echo $this->config['cp_jt']=='1' ? ' selected' : ''?>>静态
                        </option>
                        <option value="0" <?php echo $this->config['cp_jt']=='0' ? ' selected' : ''?>>动态
                        </option>
                    </select>
                </div>
            </div>
            
            
    	
	<link href="<?php echo $this->config['cdnpublic']?>bootstrap-colorpicker/3.0.0-beta.3/css/bootstrap-colorpicker.min.css" rel="stylesheet"/>
	<script src="/<?php echo $this->config['cdnpublic']?>bootstrap-colorpicker/3.0.0-beta.3/js/bootstrap-colorpicker.min.js"></script>	  
        <div class="form-group">
               <label for="gmpanel" class="col-md-2 control-label">
                    前端配色：
              </label>
              	<div class="col-md-4 input-group colorpicker-component"  id="color" >                  
				<input type="text" class="form-control input-lg" name="color" data-color="<?php echo $this->config['color'];?>"/>
				 <span class="input-group-addon"><i></i></span>
			</div>
      </div>
      
      
            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>
<script type="text/javascript">
$(function () {
		      $('#color').colorpicker({
		      format: "rgba"
		    });
		});
  	</script>
    <?php require_once 'footer.php' ?>