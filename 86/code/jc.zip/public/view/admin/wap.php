<?php require_once 'header.php' ?>
    <div class="set set0">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>wap/save"
              method="post" autocomplete="off">
            <div class="form-group">
               <label for="wapindex" class="col-md-2 control-label">
                    首页模式：
              </label>
			  <div class="col-md-9">
							<div class="col-sm-6 col-md-3">
								<div class="thumbnail">
									<img src="/static/admin/muban/wap1.jpg" 
									alt="列表模式" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>列表模式</h3>
										
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="wapindex" id="wapindex" value="1" <?php if ($this->config['wapindex'] == 1): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								</div>
							</div>
							<div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/wap2.jpg" 
									 alt="仿gmpanel" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>仿gmpanel</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="wapindex" id="wapindex" value="2" <?php if ($this->config['wapindex'] == 2): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
						
							
							<div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/wap3.jpg" 
									 alt="列表格子" style="height: auto;">
									<div class="caption" style="text-align: center;">
										<h3>列表格子</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="wapindex" id="wapindex" value="3" <?php if ($this->config['wapindex'] == 3): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							  <div class="col-sm-6 col-md-3">
								 <div class="thumbnail">
									<img src="/static/admin/muban/wap4.jpg" 
									 alt="分类模式A" style="height: auto;">
									<div class="caption">
										<h3>分类模式A</h3>
									   
										<p>
											 <label class="radio-inline">
											  <input type="radio" name="wapindex" id="wapindex" value="4" <?php if ($this->config['wapindex'] == 4): ?>checked<?php endif; ?>>启用
											</label>
										</p>
									</div>
								 </div>
							</div>
							
							
				</div>  
      </div>
            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>
    <?php require_once 'footer.php' ?>