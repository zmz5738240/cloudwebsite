<?php require_once 'header.php' ?>
    <h3>
        <span class="current">
            下载列表
        </span>
        &nbsp;/&nbsp;
        <span>
            添加下载
        </span>
    </h3>
    <br>
    <div class="set set0 table-responsive">
    <div class="panel panel-default">
        <div class="panel-body">
            <form class="form-inline" action="" method="get">
                <div class="form-group">
                    <select name="gid" class="form-control">
                        <option value="-1"<?php echo $search['gid'] == '-1' ? ' selected' : '' ?>>全部商品
                        </option>

                        <?php foreach ($class as $key => $val): ?>
                            <option value="<?php echo $val['id'] ?>"<?php echo $val['id'] == $search['gid'] ? ' selected' : '' ?>><?php echo $val['gname'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="kano" placeholder="下载内容" value="<?php echo $search['kano'] ?>"
                           size="14">
                </div>
                <button type="submit" class="btn btn-primary">
                    <span class="glyphicon glyphicon-search">
                    </span>
                    &nbsp;立即查询
                </button>
            </form>
        </div>
        <div class="panel-body">
            <button onclick="checkOrder('<?php echo $this->dir?>down/delall',9)" type="button" class="btn btn-danger">
                    <span class="glyphicon glyphicon-trash">
                    </span>
                &nbsp;批量删除
            </button>
        </div>
    </div>
    <div class="set set0">
        <table class="table table-hover">
            <thead>
            <tr class="info">
                <th>
                    <input type="checkbox"  id="checkAll" class="checkbox">
                </th>
                <th class="text-center">
                    编号
                </th>
                <th>
                    商品名称
                </th>
                <th>
                    下载地址
                </th>
                <th class="text-center">
                    操作
                </th>
            </tr>
            </thead>
            <tbody>
            <?php if($lists):?>
                <?php foreach($lists as $key=>$val):?>
                    <tr data-id="<?php echo $val['id']?>">
                        <td>
                            <input type="checkbox" name="checkname" value="<?php echo $val['id']?>" class="checkbox">
                        </td>
                        <td class="text-center">
                            <?php echo $val[ 'id']?>
                        </td>
                        <td>
                            <?php echo $val[ 'gname']?>
                        </td>
                        <td>
                            <?php echo $val[ 'kano']?>
                        </td>
                        <td class="text-center">
                            <a href="javascript:;" onclick="del(<?php echo $val['id']?>,'<?php echo $this->dir?>down/del')"
                               data-toggle="tooltip" title="删除">
                                    <span class="glyphicon glyphicon-trash">
                                    </span>
                            </a>
                        </td>
                    </tr>
                <?php endforeach;?>
            <?php else:?>
                <tr>
                    <td colspan="5">
                        no data.
                    </td>
                </tr>
            <?php endif;?>
            </tbody>
        </table>
    </div>
<?php echo $lists ? $pagelist : ''?>
    </div>


    <div class="set set1 hide">



        <form class="form-horizontal" action="<?php echo $this->dir ?>down/save"
              method="post" autocomplete="off" enctype="multipart/form-data">

            <div class="form-group">
                <label for="type" class="col-md-2 control-label">
                    请选择商品：
                </label>
                <div class="col-md-3">
                    <select name="gid" class="form-control" id="sc-good">
						<?php foreach ($class as $key => $val): ?>
                            <option value="<?php echo $val['id'] ?>"><?php echo $val['gname'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                </div>
            </div>
            <div class="form-group">
                <label for="kano" class="col-md-2 control-label">
                    下载内容：
                </label>
                <div class="col-md-4">
                    <textarea name="kano" style="width:100%;height:300px;"></textarea>
                </div>
            </div>
         



            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>




    </div>

<?php require_once 'footer.php' ?>