<?php require_once 'header.php' ?>
    <style>
.table table {
    color: #666;
    width: 100%;
    border: 1px solid #e1e6eb;
    border-bottom: 0;
    font-size: 12px;
}
.table table th {
    background: #f5f6fa;
    height: 37px;
    padding: 0 15px;
}
.table table tr {
    background: #fff;
    text-align: center;
    border-bottom: 1px solid #e1e6eb;
}
.table table td {
    height: 50px;
}

    </style>
    
<script src="<?php echo $this->config['cdnpublic']?>layer/3.1.1/layer.js"></script>
<script src="/static/admin/lay/laytpl.js" ></script>
<link href="https://www.layuicdn.com/layui-v1.0.9/css/layui.css" rel="stylesheet">

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="ibox float-e-margins">
        <div class="ibox-content">
				<div class="layui-form" id="view">
				    <table class="layui-table mt10" lay-even="" lay-skin="row">
				        <tbody>
				            <tr>
				                <td align="center" style="padding:50px 0" class="mcolor font18 cloudBind" id="loading">请稍等，正在检查最新版......</td>
				            </tr>
				        </tbody>
				    </table>
				</div>
				<script type="text/html" id="template">
				    <table class="layuitable">
				        <thead>
				            <tr>
				                <th width="150px">新版本</th>
				                <th style="text-align:left;">更新日志</th>
				                <th width="150px">操作</th>
				            </tr> 
				        </thead>
				        <tbody>
                            {{# for(var i=0;i<d.length;i++){  }}
				            <tr>
				                <td>{{d[i].version}}</td>
				                <td style="text-align:left;padding:10px 0px;">{{d[i].content}}</td>
				                <td>
                                    {{# if(d[i].isupgrade){ }}
                                        <a href="javascript:;" data-version="{{d[i].version}}" rel="更新以后将不能回退" class="btn btn-primary doUpgrade">更新至此版本</a>
                                    {{#  } }}
				                </td>
				            </tr>
                        {{# } }}
				        </tbody>
				    </table>
				
				</script>
				<div class="table" id="template_list">
				</div>
			</div>
		</div>
	</div>
    <?php require_once 'footer.php' ?>
<script>

 getVersion();
    // 执行升级，
    $(document).on('click', '.doUpgrade', function(){
        var that = $(this);
        if (that.attr('rel')) {
            layer.confirm(that.attr('rel'), {
                title: "版本更新提示",
                btnAlign: 'c',
                resize: false,
                icon: 7,
                btn: ['确定更新', '我再想想'],
                yes: function () {
                    
	            layer.close(); 
                    upgrade(that);
                }
            });
        }else{
            layer.close(); 
            upgrade(that);
        }
    });
    function upgrade(that){
        layer.msg('正在获取 '+that.attr('data-version')+' 升级包....',{time:500000});
        $.ajax({
            type: "POST",
            url: '<?php echo $this->dir?>Upgrade/down',
            data: 'version='+that.attr('data-version'),
            success: function(res) {
                if (res.code == 1) {
                    layer.msg('升级包获取成功，正在安装 '+that.attr('data-version')+' ...', {time:50000});
                    $.ajax({
                        type: "POST",
                        url: '<?php echo $this->dir?>Upgrade/install',
                        data: 'file='+res.msg+'&version='+that.attr('data-version'),
                        success: function(res) {
                            layer.msg(res.msg, {}, function() {
                                
                                location.href= '<?php echo $this->dir?>Upgrade';
                            });
                        }
                    });
                } else {
                    layer.msg(res.msg, {}, function(){
                        location.href= '';
                    });
                }
            }
        });
        return false;
    }
    

// 获取可升级版本
function getVersion() {
    $('#loading').html('请稍等，正在检查最新版......');
    $.ajax({
        type: "POST",
        url: '<?php echo $this->dir?>Upgrade/getVersion',
        success: function(res) {
            if (res.code == 1) {
                var getTpl = document.getElementById('template').innerHTML;
                if (res.data == '') {
                    $('#loading').html('您当前的版本号已经是最新了哦！');
                    return false;
                }
                document.getElementById("view").style.display="none";//隐藏
                laytpl(getTpl).render(res.data, function(html) {
                    document.getElementById('template_list').innerHTML = html;
                });
            } else {
                $('#loading').html('<a href="javascript:;" class="mcolor2"><span style="color:red;">'+res.msg+'</span></a>');
            }
        }
    });
}
</script>
</body>
</html>