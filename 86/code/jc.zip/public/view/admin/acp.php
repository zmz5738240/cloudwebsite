<?php require_once 'header.php' ?>
    <div class="set set0">
        <form class="form-ajax form-horizontal" action="<?php echo $this->dir?>acp/save"
              method="post" autocomplete="off">
					<div class="form-group">
						<label for="pay_alipay" class="col-md-2 control-label">
							支付宝：
						</label>
						<div class="col-md-4">
							 <label class="radio-inline">
							  <input type="radio" name="pay_alipay" value="0" <?php echo $this->config['pay_alipay']=='0' ? ' checked' : ''?>> 关闭
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_alipay" value="mazf" <?php echo $this->config['pay_alipay']=='mazf' ? ' checked' : ''?>> Lanpay码支付
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_alipay" value="mqpay"<?php echo $this->config['pay_alipay']=='mqpay' ? ' checked' : ''?>> 安卓监控
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_alipay" value="lailiyun"<?php echo $this->config['pay_alipay']=='lailiyun' ? ' checked' : ''?>> 蓝支付
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_alipay" value="zfbf2f"<?php echo $this->config['pay_alipay']=='zfbf2f' ? ' checked' : ''?>> 当面付
							</label>
					</div>
				</div>
				<div class="form-group">
						<label for="pay_wxpay" class="col-md-2 control-label">
							微信支付：
						</label>
						<div class="col-md-6">
							 <label class="radio-inline">
							  <input type="radio" name="pay_wxpay" value="0"<?php echo $this->config['pay_wxpay']=='0' ? ' checked' : ''?>> 关闭
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_wxpay" value="mazf" <?php echo $this->config['pay_wxpay']=='mazf' ? ' checked' : ''?>> Lanpay码支付
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_wxpay" value="mqpay"<?php echo $this->config['pay_wxpay']=='mqpay' ? ' checked' : ''?>> 安卓监控
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_wxpay" value="wx" <?php echo $this->config['pay_wxpay']=='wx' ? ' checked' : ''?>> 官方native支付
							</label>
					</div>
				</div>
				
					<div class="form-group">
						<label for="pay_jhpay" class="col-md-2 control-label">
							聚合码：
						</label>
						<div class="col-md-4">
							 <label class="radio-inline">
							  <input type="radio" name="pay_jhpay" value="0" <?php echo $this->config['pay_jhpay']=='0' ? ' checked' : ''?>> 关闭
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_jhpay" value="mazf" <?php echo $this->config['pay_jhpay']=='mazf' ? ' checked' : ''?>> Lanpay码支付
							</label>
							<label class="radio-inline">
							  <input type="radio" name="pay_jhpay" value="mqpay"<?php echo $this->config['pay_jhpay']=='mqpay' ? ' checked' : ''?>> 安卓监控
							</label>
					</div>
				</div>
				
				
		<div class="form-group">
			<label class="col-md-2 control-label">支付宝应用appid：</label>
			<div class="col-md-4">                                              
				<input type="text" class="form-control" name="app_id" value="<?php echo $this->config['app_id']?>"> 				
			</div>			
			<span class="col-md-4">
				<i class="glyphicon glyphicon-info-sign"></i><a href="https://b.alipay.com/settling/index.htm?appId=2017102409502568" target="_blank">当面付开通</a>
			</span>
		</div>                                 
		
		<div class="form-group">
			<label class="col-md-2 control-label">支付宝公钥：</label>
			<div class="col-md-4">                     
				<input type="text" class="form-control" name="ali_public_key" value="<?php echo $this->config['ali_public_key']?>">                                                                                  
			</div>		
		
		</div>                         
		
		<div class="form-group">
			<label class="col-md-2 control-label">alipay应用私钥：</label>
			<div class="col-md-4">                                     
				<input type="text" class="form-control" name="rsa_private_key" value="<?php echo $this->config['rsa_private_key']?>">
			</div>	
		</div>                      
		
		<div class="form-group">
			<label class="col-md-2 control-label">微信支付商户号：</label>
			<div class="col-md-4">                                              
				<input type="text" class="form-control" name="mch_id" value="<?php echo $this->config['mch_id']?>">    
			</div>
		</div>
		
		<div class="form-group">
			<label class="col-md-2 control-label">微信支付APPID：</label>											
			<div class="col-md-4">                                              
				<input type="text" class="form-control" name="wx_appid" value="<?php echo $this->config['wx_appid']?>">    
			</div>
		</div>                    
		
		<div class="form-group">
			<label class="col-md-2 control-label">微信支付API密钥：</label>
			<div class="col-md-4">                      
				<input type="text" class="form-control" name="wx_apiKey" value="<?php echo $this->config['wx_apiKey']?>">
			</div>
		</div>
		
		
		<div class="form-group">
			<label class="col-md-2 control-label">蓝支付对接ID：</label>
			<div class="col-md-4">                        
				<input type="text" class="form-control" name="pay_yzfid" value="<?php echo $this->config['pay_yzfid']?>">
			</div>
			<span class="col-md-4">
				<i class="glyphicon glyphicon-info-sign"></i><a href="http://xw.wyisp.com/" target="_blank">蓝支付申请账号</a>
			</span>
		</div>								
		<div class="form-group">
			<label class="col-md-2 control-label">蓝支付对接Token：</label>
			<div class="col-md-4">                        
				<input type="text" class="form-control" name="pay_yzfkey" value="<?php echo $this->config['pay_yzfkey']?>">
			</div>			
			<span class="col-md-4">
				<i class="glyphicon glyphicon-info-sign"></i>蓝支付免营业执照轮询收款
			</span>
		</div>	
		
		<div class="form-group">
			<label class="col-md-2 control-label">Lanpay码支付商户ID：</label>
			<div class="col-md-4">                        
				<input type="text" class="form-control" name="pay_mzfid" value="<?php echo $this->config['pay_mzfid']?>">
			</div>
			<span class="col-md-4">
				<i class="glyphicon glyphicon-info-sign"></i><a href="http://mzf.lailiyun.com/user/login?id=1" target="_blank">码支付开通</a>
			</span>
		</div>								
		<div class="form-group">
			<label class="col-md-2 control-label">Lanpay码支付商户密钥：</label>
			<div class="col-md-4">                        
				<input type="text" class="form-control" name="pay_mzfkey" value="<?php echo $this->config['pay_mzfkey']?>">
			</div>
		</div>	
		
            <div class="form-group">
                <label for="siteinfo" class="col-md-2 control-label">
                    自定义商品名：
                </label>
                <div class="col-md-4">
                    <input type="text" name="diyname" id="diyname" class="form-control"
                    value="<?php echo $this->config['diyname']?>">
                </div>
                <span class="col-md-4">
                    用于官方接口订单商品名称 为空则为订单号
                </span>
            </div>
            <div class="form-group">
                <label for="siteinfo" class="col-md-2 control-label">
                    支付说明：
                </label>
                <div class="col-md-6">
                    <input type="text" name="payinfo" id="payinfo" class="form-control"
                    value="<?php echo $this->config['payinfo']?>">
                </div>
                <span class="col-md-4">
                    显示在部分支付方式支付界面
                </span>
            </div>		
				
				
				
				
				
				


            <div class="form-group">
                <label for="stacode" class="col-md-2 control-label">
                </label>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-success">
                        &nbsp;
                        <span class="glyphicon glyphicon-save">
                        </span>
                        &nbsp;保存设置&nbsp;
                    </button>
                </div>
                <span class="col-md-6">
                </span>
            </div>
        </form>
    </div>
    <?php require_once 'footer.php' ?>	