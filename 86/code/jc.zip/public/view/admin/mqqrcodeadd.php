<?php require_once 'header.php' ?>
<link rel="stylesheet" type="text/css" href="https://www.layuicdn.com/layui-v2.4.5/css/layui.css?v=201811010202">
</br>
</br>
<div class="layui-form" action="">
    

    <div class="layui-form-item">
        <label class="layui-form-label">收款方式</label>
        <div class="layui-input-block">
            <div class="layui-upload">
                <select id="type">
                    <option value="1">支付宝</option>
                    <option value="2">聚合码</option>
                    <option value="3">微信</option>
                </select>
            </div>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">解码后的url</label>
        <div class="layui-input-block">
            <input type="text" id="url" lay-verify="required" placeholder="收款码解码后的url" autocomplete="off" class="layui-input">
        </div>
    </div>
	
    <div class="layui-form-item">
        <label class="layui-form-label">金额</label>
        <div class="layui-input-block">
            <input type="text" id="money" lay-verify="required" placeholder="金额" autocomplete="off" class="layui-input">
        </div>
    </div>

	<div class="layui-form-item" style="text-align: left;">
       <button class="layui-btn" onclick="window.open('https://jiema.wwei.cn')">收款码解码地址</button>
    </div>
	
	

    <div class="layui-form-item" style="text-align: right;">
        <button class="layui-btn" onclick="save()">保存</button>
    </div>

</div>

    <script src="https://www.layuicdn.com/layui-v2.4.5/layui.js?v=201811010202"></script>


<script>
   function formatDate(now) {
        now = new Date(now*1000);
        return now.getFullYear()
            + "-" + (now.getMonth()>8?(now.getMonth()+1):"0"+(now.getMonth()+1))
            + "-" + (now.getDate()>9?now.getDate():"0"+now.getDate())
            + " " + (now.getHours()>9?now.getHours():"0"+now.getHours())
            + ":" + (now.getMinutes()>9?now.getMinutes():"0"+now.getMinutes())
            + ":" + (now.getSeconds()>9?now.getSeconds():"0"+now.getSeconds());

    }


    layui.use(['form','layer'], function(){
        var table = layui.table,form = layui.form;
        form.render();
	});

    function save() {
        var type = $("#type").val();
        var money = $("#money").val();
        var url = $("#url").val();
      
        if (type == ""){
            layer.msg("请选择收款码类型");
            return;
        }
        if (money == ""){
            layer.msg("请输入收款码金额");
            return;
        }

        if (url == ""){
            layer.msg("请输入收款码URL");
            return;
        }
		  
        $.post("addPayQrcode","type="+type+"&price="+money+"&pay_url="+url,function (data) {
            if (data.code==1){
        
            }
            layer.msg(data.msg);
        });
    }



</script>
    <?php require_once 'footer.php' ?>	